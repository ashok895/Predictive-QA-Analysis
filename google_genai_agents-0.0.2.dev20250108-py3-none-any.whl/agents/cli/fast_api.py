import importlib
import sys
from typing import Any
from typing import Optional

from fastapi import FastAPI
from fastapi import HTTPException
from google.genai import types
from pydantic import BaseModel
from uvicorn.main import run as uvicorn_run

from ..agents import Agent
from ..artifacts import InMemoryArtifactService
from ..events import Event
from ..runners import Runner
from ..sessions import InMemorySessionService
from ..sessions import PostgresSessionService
from ..sessions import Session
from .utils import envs


class AgentRunRequest(BaseModel):
  session_id: str
  new_message: types.Content


def run_fast_api(
    *,
    agent_dir: str,
    agent_name: str,
    session_db_url: str = "",
) -> None:
  if agent_dir not in sys.path:
    sys.path.append(agent_dir)

  agent_module = importlib.import_module(agent_name)
  root_agent: Agent = agent_module.agent.root_agent
  envs.load_dotenv_for_agent(agent_name, agent_dir)

  artifact_service = InMemoryArtifactService()
  if not session_db_url:
    session_service = InMemorySessionService()
  else:
    session_service = PostgresSessionService(db_url=session_db_url)
  app = FastAPI()

  runner = Runner(root_agent, artifact_service, session_service)

  @app.get("/sessions/{session_id}", response_model_exclude_none=True)
  def get_session(session_id: str) -> Session:
    session = session_service.get(session_id)
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")
    return session

  @app.get("/sessions", response_model_exclude_none=True)
  def list_sessions() -> list[str]:
    return session_service.list()

  @app.post("/sessions/{session_id}", response_model_exclude_none=True)
  def create_session(
      session_id: str, context: Optional[dict[str, Any]] = None
  ) -> Session:
    return session_service.create(context, session_id=session_id)

  @app.delete("/sessions/{session_id}")
  def delete_session(session_id: str):
    session_service.delete(session_id)

  @app.post("/agent/run", response_model_exclude_none=True)
  def agent_run(req: AgentRunRequest) -> list[Event]:
    session = session_service.get(req.session_id)
    if not session:
      raise HTTPException(status_code=404, detail="Session not found")

    return list(runner.run(session=session, new_message=req.new_message))

  uvicorn_run(app, host="0.0.0.0", log_config=None)
