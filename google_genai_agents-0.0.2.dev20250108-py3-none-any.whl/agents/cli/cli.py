import importlib
import os
import sys
from datetime import datetime

from google.genai import types
from pydantic import BaseModel

from agents import Agent
from agents import Runner
from agents.artifacts import BaseArtifactService
from agents.artifacts import InMemoryArtifactService
from agents.sessions import BaseSessionService
from agents.sessions import InMemorySessionService
from agents.sessions import Session

from .utils import envs


class InputFile(BaseModel):
  context: dict[str, object]
  queries: list[str]


def run_input_file(
    root_agent: Agent,
    artifact_service: BaseArtifactService,
    session: Session,
    session_service: BaseSessionService,
    input_path: str,
) -> None:
  runner = Runner(root_agent, artifact_service, session_service)

  # Reads from the input json file.
  with open(input_path, 'r') as f:
    input_file = InputFile.model_validate_json(f.read())
  input_file.state['_time'] = datetime.now()

  session.state = input_file.state
  for query in input_file.queries:
    print('user: ', query)
    content = types.Content(role='user', parts=[types.Part(text=query)])
    for event in runner.run(session=session, new_message=content):
      if event.is_final_response():
        print(event.content.parts[0].text)


def run_interactively(
    root_agent: Agent,
    artifact_service: BaseArtifactService,
    session: Session,
    session_service: BaseSessionService,
) -> None:
  runner = Runner(root_agent, artifact_service, session_service)
  while True:
    query = input('user: ')
    if query == 'exit':
      break
    for event in runner.run(
        session=session,
        new_message=types.Content(role='user', parts=[types.Part(text=query)]),
    ):
      if event.is_final_response():
        print(f'[{event.author}]: {event.content.parts[0].text}')


def run_cli(
    *,
    agent_parent_dir: str,
    agent_folder_name: str,
    json_file_path: str | None,
    save_session: bool,
) -> None:
  """Runs an interactive CLI for a certain agent.

  Args:
    agent_parent_dir: str, the absolute path of the parent folder of the agent
      folder.
    agent_folder_name: str, the name of the agent folder.
    json_file_path: str | None, the absolute path to the json file, either
      *.input.json or *.session.json.
    save_session: bool, whether to save the session on exit.
  """
  if agent_parent_dir not in sys.path:
    sys.path.append(agent_parent_dir)

  artifact_service = InMemoryArtifactService()
  session_service = InMemorySessionService()
  session = session_service.create()

  agent_module_path = os.path.join(agent_parent_dir, agent_folder_name)
  agent_module = importlib.import_module(agent_folder_name)
  root_agent = agent_module.agent.root_agent
  envs.load_dotenv_for_agent(agent_folder_name, agent_parent_dir)
  if json_file_path:
    if json_file_path.endswith('.input.json'):
      run_input_file(root_agent, session, session_service, json_file_path)
    elif json_file_path.endswith('.session.json'):
      with open(json_file_path, 'r') as f:
        session = Session.model_validate_json(f.read())
      for content in session.get_contents():
        if content.role == 'user':
          print('user: ', content.parts[0].text)
        else:
          print(content.parts[0].text)
      run_interactively(root_agent, artifact_service, session, session_service)
    else:
      print(f'Unsupported file type: {json_file_path}')
      exit(1)
  else:
    print(f'Running agent {root_agent.name}, type exit to exit.')
    run_interactively(root_agent, artifact_service, session, session_service)

  if save_session:
    if json_file_path:
      session_path = json_file_path.replace('.input.json', '.session.json')
    else:
      session_id = input('Session ID to save: ')
      session_path = f'{agent_module_path}/{session_id}.session.json'
    with open(session_path, 'w') as f:
      f.write(session.model_dump_json(indent=2, exclude_none=True))
    # TODO: Save from opentelemetry.
    # logs_path = session_path.replace('.session.json', '.logs.json')
    # with open(logs_path, 'w') as f:
    #   f.write(
    #       session.model_dump_json(
    #           indent=2, exclude_none=True, include='event_logs'
    #       )
    #   )
    print('Session saved to', session_path)
