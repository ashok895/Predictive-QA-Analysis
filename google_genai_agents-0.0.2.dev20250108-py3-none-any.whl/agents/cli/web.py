import logging
import os
import typing

from opentelemetry import trace
from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter
from opentelemetry.sdk.trace import export
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace import TracerProvider
import streamlit as st
from ui import agent_tab
from ui import app_context
from ui import artifacts_tab
from ui import chat
from ui import eval_tab
from ui import state_tab


class SessionStateSpanExporter(export.SpanExporter):

  def export(
      self, spans: typing.Sequence[ReadableSpan]
  ) -> export.SpanExportResult:
    for span in spans:
      if span.name == 'call_llm':
        st.session_state.call_llm_spans[span.attributes['event_id']] = dict(
            span.attributes
        )
    return export.SpanExportResult.SUCCESS

  def force_flush(self, timeout_millis: int = 30000) -> bool:
    return True


provider = TracerProvider()
provider.add_span_processor(
    export.SimpleSpanProcessor(SessionStateSpanExporter())
)

if os.environ.get('AF_TRACE_TO_CLOUD', '0') == '1':
  processor = export.BatchSpanProcessor(
      CloudTraceSpanExporter(project_id=os.environ['GOOGLE_CLOUD_PROJECT'])
  )
  provider.add_span_processor(processor)

trace.set_tracer_provider(provider)

st.set_page_config(
    page_title='GenAI Agent Demos',
    layout='wide',
)


logger = logging.getLogger(__name__)


# Makes dialog bigger.
st.markdown(
    """<style>
/* Wider dialog. */
div[role="dialog"] {
    width: 80%;
}
/* Remove extra top padding in the sidebar. */
div[data-testid="stSidebarHeader"] {
    height: 16px;
    padding: 0;
}
/* Horizontal layout for function call steps. */
div[class*="st-key-row_layout_"] {
    flex-direction: row !important;
    flex-wrap: wrap;
    gap: 8px;
}
div[class*="st-key-row_layout_"] div {
    width: max-content !important;
}
/* Chat history row layout. */
div[class*="st-key-chat_row_"] {
    flex-direction: row !important;
    flex-wrap: nowrap;
}
div[class*="st-key-chat_row_"] div:last-child {
    flex: 1;
}
/* Smaller step buttons. */
div[class*="st-key-row_layout_fc_"] button {
    min-height: 0 !important;
}
div[class*="st-key-row_layout_fc_"] p {
    font-size: 12px !important;
}
/* Smaller json view. */
.react-json-view {
    font-size: 12px !important;
}
/* Fixed width font for state edit. */
.st-key-state_json textarea {
    font-family: "Source Code Pro", monospace;
    font-size: 14px;
}
/* Show agent initial on the avatar button. */
div[class*="st-key-avatar_"] button > span {
    margin-right: 4px;
}
div[class*="st-key-avatar_"] button > div {
    position: absolute;
    top: 0;
    right: 6px;
    font-size: 12px;
}
</style>""",
    unsafe_allow_html=True,
)


app_context.setup_session_state()

st.sidebar.subheader('Agent Framework Dev UI')
agent_panel, state_panel, artifacts_panel, eval_panel = st.sidebar.tabs(
    ['Agent', 'State', 'Artifacts', 'Eval']
)

with agent_panel:
  agent_tab.render()
# Renders chat before other tabs so they can be updated by chat.
if st.session_state.demo_name:
  chat.render_chat()
with state_panel:
  state_tab.render()
with artifacts_panel:
  artifacts_tab.render()
with eval_panel:
  eval_tab.render()
