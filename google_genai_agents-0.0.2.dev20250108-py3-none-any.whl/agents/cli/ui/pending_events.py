import json

from agents.events import Event
import streamlit as st

from . import app_context

run_every = None


@st.fragment(run_every=run_every)
def auto_refresh_for_pending_events():
  session = st.session_state.session
  if st.session_state.event_num != len(session.events):
    st.session_state.event_num = len(session.events)
    st.rerun()


def start_or_stop_auto_refresh_for_pending_events():
  global run_every
  session = st.session_state.session
  session_service = app_context.get_session_service()
  if session_service.list_pending_events(session.id):
    run_every = '3s'
    auto_refresh_for_pending_events()
  else:
    run_every = None


@st.dialog('Pending event')
def pending_event_dialog(
    function_call_event,
    function_call,
    function_resposne_events,
):
  st.write(f'Pending function call: {function_call.name}')
  st.json(function_call.args)
  with st.form('result_form'):
    result = st.text_area('Result')
    if st.form_submit_button('Submit'):
      result_value = json.loads(result) if result.startswith('{') else result
      if not isinstance(result_value, dict):
        result_value = {'result': result_value}
      function_resposne_event = Event.from_function_response(
          function_call_event, function_call, result_value
      )
      function_resposne_events.append(function_resposne_event)
      if len(function_resposne_events) == len(
          function_call_event.get_function_calls()
      ):
        # when all the function responses are generated
        merged_response_event = Event.merge_parallel_function_response_events(
            function_resposne_events
        )
        session = st.session_state.session
        session_service = app_context.get_session_service()
        session_service.append_event(session, merged_response_event)
        list(
            app_context.get_runner().run(
                session=session,
                new_message=None,
                stream=st.session_state.get('streaming', False),
            )
        )
      st.rerun()


def render_pending_events_button():
  session = st.session_state.session
  session_service = app_context.get_session_service()
  pending_events = session_service.list_pending_events(session.id)
  start_or_stop_auto_refresh_for_pending_events()

  with st.popover(
      f'Pending events ({len(pending_events)})', use_container_width=True
  ):
    for pending_event in pending_events:
      function_call_event = pending_event.function_call_event
      function_resposne_events = pending_event.function_response_events
      function_calls = function_call_event.get_function_calls()
      for function_call in function_calls:
        name = (
            f"{function_call.name}({','.join([str(x) for x in function_call.args.values()])})"
        )
        if st.button(
            name,
            key=f'pending_{function_call_event.id}_{name}',
            use_container_width=True,
        ):
          pending_event_dialog(
              function_call_event,
              function_call,
              function_resposne_events,
          )
