import io
import logging

import streamlit as st
from PIL import Image

logger = logging.getLogger(__name__)

def render():
  artifact_service = st.session_state.artifact_service
  session_id = st.session_state.session.id

  filenames = artifact_service.list(session_id).filenames

  if not filenames:
    return

  for key in filenames:
    logger.info(f'Render artifacts key {key}')

    versions = artifact_service.list_versions(session_id, key).versions
    if not versions:
      pass

    with st.popover(key):
      tab_names = ['Latest']
      for i in range(len(versions) - 2, -1, -1):
        tab_names.append(f'{i + 1}')
      version = st.segmented_control(
          'Versions',
          options=tab_names,
      )
      if not version:
        version = 'Latest'
      index = len(versions) - 1 - tab_names.index(version)
      artifact = versions[index]

      if artifact.inline_data:
        st.download_button(
            label='Download',
            data=artifact.inline_data.data,
            file_name=key,
            mime=artifact.inline_data.mime_type,
            key=f'download_{key}_{index}',
        )
      elif artifact.file_data:
        st.download_button(
            label='Download',
            data=artifact.file_data.file_uri,
            file_name=key,
            mime=artifact.file_data.mime_type,
            key=f'download_{key}_{index}',
        )

    # Renders the artifact.
    if artifact.inline_data:
      if artifact.inline_data.mime_type.startswith('image/'):
        st.write(Image.open(io.BytesIO(artifact.inline_data.data)))
      elif artifact.inline_data.mime_type.startswith('application/pdf'):
        # Don't try to render it.
        pass
      else:
        st.write(artifact.inline_data.data)
    elif artifact.file_data:
      if artifact.file_data.mime_type.startswith('text/html'):
        st.components.v1.html(
            artifact.file_data.file_uri, height=500, scrolling=True
        )
    else:
      st.code(artifact.text)
