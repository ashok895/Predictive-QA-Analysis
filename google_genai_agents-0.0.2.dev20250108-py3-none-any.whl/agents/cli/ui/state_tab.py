import json
import streamlit as st

def save_state():
  session = st.session_state.session
  session.state = json.loads(st.session_state.get('state_json', ''))
  st.session_state.edit_state = False


def cancel_edit_state():
  st.session_state.edit_state = False


def start_edit_state():
  st.session_state.edit_state = True


# st.fragment is needed to avoid rerun the whole, in which case the state
# wont'be updated.
@st.fragment
def render():
  session = st.session_state.session

  if st.session_state.edit_state:
    with st.container(key='row_layout_state'):
      st.button('Save', on_click=save_state)
      st.button('Cancel', on_click=cancel_edit_state)
    state_json = json.dumps(session.state, indent=2)
    st.text_area(
        'Edit',
        state_json,
        height=500,
        key='state_json',
    )
  else:
    st.button('Edit', on_click=start_edit_state)
    st.write(session.state)
