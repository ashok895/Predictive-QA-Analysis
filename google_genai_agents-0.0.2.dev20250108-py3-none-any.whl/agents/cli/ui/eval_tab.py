import json
import os

import streamlit as st

from . import app_context


def render():
  if st.button('Save session as test file', use_container_width=True):
    save_session_as_test_file_dialog()

  if st.button('Run test file', use_container_width=True):
    run_session_as_test_file_dialog()


@st.dialog('Save session as test file')
def save_session_as_test_file_dialog():
  session_name = st.text_input(
      'Test file name',
      value=st.session_state.selected_session,
      key='session_name_input',
  )
  save_button_clicked = st.button('Save', key='test_file_save_button')

  if save_button_clicked:
    try:
      # Convert the session data to evaluation format
      test_data = convert_session_format_to_eval_format(
          st.session_state.session.model_dump()
      )

      # Serialize the test data to JSON
      test_data_str = json.dumps(test_data, indent=2)

      # Define the file path
      test_file_path = os.path.join(
          app_context.get_agent_folder(),
          st.session_state.demo_name,
          session_name + '.test.json',
      )

      # Write the JSON string to the file
      with open(test_file_path, 'w') as f:
        f.write(test_data_str)

      # Provide feedback on the UI
      st.success(f'File saved successfully as: {test_file_path}')

    except Exception as e:
      # Display an error message if something goes wrong
      st.error(f'An error occurred while saving the file: {str(e)}')


@st.dialog('Run selected test files')
def run_session_as_test_file_dialog(agent_folder):
  # Directory containing the test files
  test_files_directory = os.path.abspath(
      os.path.join(agent_folder, st.session_state.demo_name)
  )

  # Fetch all `.test.json` files recursively in the directory
  test_files = []
  for root, _, files in os.walk(test_files_directory):
    for file in files:
      if file.endswith('.test.json'):
        test_files.append(os.path.join(root, file))

  if not test_files:
    st.warning('No test files found in the directory.')
    return

  # Display test files with a multiselect widget
  selected_files = st.multiselect(
      'Select test files to run:',
      test_files,
      default=[],
      key='selected_test_files',
  )

  # Add a checkbox to run all files
  run_all = st.checkbox('Run All Test Files', key='run_all_checkbox')

  # Add a "Run Tests" button
  run_button_clicked = st.button('Run Tests', key='run_selected_tests_button')

  if run_button_clicked:
    # Determine files to run based on user selection or "Run All"
    files_to_run = test_files if run_all else selected_files

    if not files_to_run:
      st.warning('No files selected to run.')
      return

    # Display the list of test files being run
    st.write('### Files to be tested:')
    for file_name in files_to_run:
      st.write(f'- {file_name}')

    try:
      with st.spinner('Running selected tests...'):
        total_files = len(files_to_run)
        progress = st.progress(0)

        for idx, file_path in enumerate(files_to_run):
          # Dynamically display each result
          with st.container():
            st.write(f'Running test: {file_path}')

            try:
              from agents.evaluation.agent_evaluator import AgentEvaluator

              res = AgentEvaluator.evaluate('home_automation_agent', file_path)
              if res is None:
                st.success(f'Test: {file_path} - Passed')
              else:
                st.success(f'Test: {file_path} - Result: {res}')
            except Exception as test_error:
              st.error(f'Test: {file_path} - Error - {str(test_error)}')

          # Update the progress bar
          progress.progress((idx + 1) / total_files)

      st.success(
          'All selected tests have been run successfully. Please check your'
          ' test results shown above.'
      )

    except Exception as e:
      # Handle unexpected errors gracefully
      st.error(f'An error occurred while running the tests: {str(e)}')


def convert_session_format_to_eval_format(session_file):
  """Converts a single session file in the new format into the accepted evaluation format.

  Args:
      session_file (dict): The detailed session log.

  Returns:
      list: A single evaluation dataset in the required format.
  """
  eval_case = []
  events = session_file.get('events', [])

  for event in events:
    if event.get('author') == 'user':
      # Extract user query
      content = event.get('content', {})
      parts = content.get('parts', [])
      if not parts:
        continue

      query = parts[0].get('text', '')  # Safely get the query text

      # Find the corresponding tool usage or response for the query
      expected_tool_use = []
      reference = None

      # Check subsequent events to extract tool uses or responses
      for subsequent_event in events[events.index(event) + 1 :]:
        subsequent_content = subsequent_event.get('content', {})
        subsequent_parts = subsequent_content.get('parts', [])
        if not subsequent_parts:
          continue

        # Safely check for function_call
        function_call = subsequent_parts[0].get('function_call', None)
        if function_call:
          tool_name = function_call.get('name', '')
          tool_input = function_call.get('args', {})
          expected_tool_use.append({
              'tool_name': tool_name,
              'tool_input': tool_input,
          })
        elif 'text' in subsequent_parts[0]:
          reference = subsequent_parts[0].get('text', '')
          break

      eval_case.append({
          'query': query,
          'expected_tool_use': expected_tool_use,
          'reference': reference,
      })

  return eval_case
