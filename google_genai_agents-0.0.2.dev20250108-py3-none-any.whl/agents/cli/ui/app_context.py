import sys
import time
import types

import streamlit as st

from agents import Agent
from agents import Runner
from agents.artifacts import InMemoryArtifactService
from agents.sessions import InMemorySessionService
from agents.sessions import PostgresSessionService


@st.cache_resource
def get_session_service():
  db_url = sys.argv[2]
  if db_url:
    return PostgresSessionService(db_url=db_url)
  else:
    return InMemorySessionService()


@st.cache_resource
def get_artifact_service():
  return InMemoryArtifactService()


# Runner can not be a cache resource because it depends on the root agent.
def get_runner():
  return Runner(get_root_agent(), get_artifact_service(), get_session_service())


@st.cache_resource
def get_agent_folder():
  agent_folder = sys.argv[1]
  if agent_folder not in sys.path:
    sys.path.append(agent_folder)
  return agent_folder


@st.cache_resource
def get_demo_modules() -> dict[str, types.ModuleType]:
  demo_modules = {}
  return demo_modules


def setup_session_state():
  if 'session' not in st.session_state:
    st.session_state.session = get_session_service().create()
  if 'artifact_service' not in st.session_state:
    st.session_state.artifact_service = get_artifact_service()
  if 'event_dialog_index' not in st.session_state:
    st.session_state.event_dialog_index = 0
  if 'file_uploader_key' not in st.session_state:
    st.session_state.file_uploader_key = str(time.time())
  if 'event_num' not in st.session_state:
    st.session_state.event_num = 0
  if 'edit_state' not in st.session_state:
    st.session_state.edit_state = False
  if 'demo_name' not in st.session_state:
    st.session_state.demo_name = None
  if 'streaming' not in st.session_state:
    st.session_state.streaming = False
  if 'call_llm_spans' not in st.session_state:
    st.session_state.call_llm_spans = {}


def get_root_agent() -> Agent:
  return get_demo_modules()[st.session_state.demo_name].agent.root_agent
