import json

import streamlit as st

from . import agent_graph
from . import app_context

@st.dialog('Event', width='large')
def show():
  root_agent = app_context.get_root_agent()
  session = st.session_state.session
  col1, col2, col3 = st.columns([90, 5, 5], vertical_alignment='center')
  has_previous = st.session_state.event_dialog_index > 0
  has_next = (
      st.session_state.event_dialog_index < len(session.events) - 1
  )

  with col2:
    if st.button('⇦', disabled=not has_previous):
      if has_previous:
        st.session_state.event_dialog_index -= 1

  with col3:
    if st.button('⇨', disabled=not has_next):
      if has_next:
        st.session_state.event_dialog_index += 1

  event_index = st.session_state.event_dialog_index
  event = session.events[event_index]
  text, details = get_event_info(event)

  with col1:
    # Uses radio buttons because they are faster than tabs.
    tabs = ['Event', 'Graph', 'Request', 'Response']
    if 'event_dialog_info_type' not in st.session_state:
      st.session_state.event_dialog_info_type = 'Event'
    info_type = st.segmented_control(
        f'Event {event_index + 1} of {len(session.events)}: {text}',
        tabs,
        selection_mode='single',
        key='event_dialog_info_type',
    )

  if info_type == 'Event':
    st.write(event.model_dump(exclude_none=True))

  if info_type == 'Graph':
    function_calls = event.get_function_calls()
    function_responses = event.get_function_responses()
    if function_calls:
      function_call_highlights = []
      for function_call in function_calls:
        from_name = event.author
        to_name = function_call.name
        function_call_highlights.append((from_name, to_name))
      st.graphviz_chart(
          agent_graph.get_agent_graph(root_agent, function_call_highlights)
      )
    elif function_responses:
      function_responses_highlights = []
      for function_response in function_responses:
        from_name = function_response.name
        to_name = event.author
        function_responses_highlights.append((from_name, to_name))
      st.graphviz_chart(
          agent_graph.get_agent_graph(root_agent, function_responses_highlights)
      )
    else:
      from_name = event.author
      to_name = ''
      st.graphviz_chart(
          agent_graph.get_agent_graph(root_agent, [(from_name, to_name)])
      )

  call_llm_span = st.session_state.call_llm_spans.get(event.id, None)
  if info_type == 'Request':
    if call_llm_span:
      st.write(json.loads(call_llm_span['llm_request']))
    else:
      st.write('No logs found for the event.')

  if info_type == 'Response':
    if call_llm_span:
      st.write(json.loads(call_llm_span['llm_response']))
    else:
      st.write('No logs found for the event.')


def get_event_info(event):
  function_calls = event.get_function_calls()
  function_responses = event.get_function_responses()
  if function_calls:
    for function_call in function_calls:
      text = f'⚡ {function_call.name}'
      details = function_call.args
      # TODO: Enable this later.
      # elif event.type == 'agent_transfer':
      #   text = f'➡️ {event.get_agent_transfer_name()}'
      #   details = None
      # elif event.type == 'agent_retrieve':
      #   function_call = event.get_function_call()
      #   text = f'🔎 {function_call.name}'
      #   details = function_call.args
  elif function_responses:
    for function_response in function_responses:
      icon = '⏳' if event.actions.pending else '✔️'
      text = f'{icon} {function_response.name}'
      details = function_response.response
  elif event.is_final_response():
    text = event.content.role + ': '
    for part in event.content.parts:
      if part.text:
        text += part.text
      elif part.inline_data and part.inline_data.mime_type.startswith('image/'):
        text += ' [IMAGE] '
      elif part.inline_data:
        text += ' [File] '
    details = text
  else:
    raise ValueError(f'Unsupported event: {event}')
  return text, details
