import copy
import importlib
import json
import logging
import os
import re

import streamlit as st

from agents import Agent
from agents.cli.utils import envs
from agents.sessions import Session

from . import agent_graph
from . import app_context
from . import pending_events

logger = logging.getLogger(__name__)


def on_demo_name_change():
  demo_name = st.session_state.demo_name
  if demo_name:
    st.query_params.app = demo_name
    import_agent_module()
    reset_session()
  else:
    st.query_params.pop('app', None)


def render():
  if not st.session_state.demo_name and 'app' in st.query_params:
    st.session_state.demo_name = st.query_params.app
    on_demo_name_change()

  st.selectbox(
      'GenAI Agent Demos',
      get_demo_names(),
      index=None,
      placeholder='Select a demo...',
      key='demo_name',
      on_change=on_demo_name_change,
  )

  if not st.session_state.demo_name:
    return

  col1, col2 = st.columns(2)
  if col1.button('Definitions', use_container_width=True):
    definitions_dialog()
  if col2.button('Reload Agent', use_container_width=True):
    import_agent_module(reload=True)
  st.selectbox(
      'Sessions',
      get_saved_sessions(),
      index=None,
      on_change=load_session,
      key='selected_session',
      placeholder='Load a saved session...',
  )
  col1, col2 = st.columns(2)
  if col1.button('Reset', use_container_width=True):
    reset_session()
    st.rerun()
  if col2.button('Save', use_container_width=True):
    save_session_dialog()
  # Enable this once fixed.
  # st.toggle('Streaming', key='streaming')

  # Enable this once fixed.
  # st.button('Rerun session', use_container_width=True, key='rerun_session')

  pending_events.render_pending_events_button()

  st.file_uploader(
      'Insert files',
      accept_multiple_files=True,
      key=st.session_state.file_uploader_key,
  )


@st.cache_resource
def get_demo_names():
  agent_folder = app_context.get_agent_folder()
  demo_names = [
      x
      for x in os.listdir(agent_folder)
      if os.path.isdir(os.path.join(agent_folder, x))
      and not x.startswith('.')
      and x != '__pycache__'
  ]
  demo_names.sort()
  logger.info('Found demos %s demos: %s', len(demo_names), demo_names)
  return demo_names


@st.dialog('Agent Definitions')
def definitions_dialog():
  agents = {}
  get_all_agents(app_context.get_root_agent(), agents)
  agent_names = list(agents.keys())
  tab_names = ['Graph'] + agent_names
  tabs = st.tabs(tab_names)
  with tabs[0]:
    st.graphviz_chart(
        agent_graph.get_agent_graph(app_context.get_root_agent(), None)
    )

  for i in range(1, len(tab_names)):
    with tabs[i]:
      agent = agents[agent_names[i - 1]]
      children_names = [child.name for child in agent.children]
      tools_names = [
          tool.__name__ if callable(tool) else tool.name for tool in agent.tools
      ]
      summary = {
          'name': agent.name,
          'description': agent.description,
          'parent': agent.parent_agent.name if agent.parent_agent else '',
          'children': children_names,
          'tools': tools_names,
      }
      for key in ['model', 'flow', 'global_instruction', 'instruction']:
        summary[key] = getattr(agent, key)
      st.json(summary)


@st.dialog('Save session')
def save_session_dialog():
  session_name = st.text_input(
      'Session name',
      value=st.session_state.selected_session,
      key='session_name_input_save_session',
  )
  save_button_clicked = st.button('Save', key='save_session_button')

  if save_button_clicked:
    # Define the session file path
    session_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        session_name + '.session.json',
    )

    # Write the session data to the file
    with open(session_path, 'w') as f:
      f.write(
          strip_bytes_data(
              copy.deepcopy(st.session_state.session)
          ).model_dump_json(indent=2, exclude_none=True)
      )
    logs_path = session_path.replace('.session.json', '.logs.json')
    print(st.session_state.call_llm_spans)
    with open(logs_path, 'w') as f:
      json.dump(st.session_state.call_llm_spans, f, indent=2)
    # Provide success feedback to the UI
    st.success(f'Session saved successfully as: {session_path}')


def get_all_agents(agent, result):
  result[agent.name] = agent
  if hasattr(agent, 'children'):
    for child in agent.children:
      get_all_agents(child, result)


# Use demo_name as cache key.
def get_saved_sessions():
  demo_dir = os.path.join(
      app_context.get_agent_folder(), st.session_state.demo_name
  )
  session_suffix = '.session.json'
  names = [
      x.removesuffix(session_suffix)
      for x in os.listdir(demo_dir)
      if x.endswith(session_suffix)
  ]
  names.sort()
  logger.info('Found sessions %s sessions: %s', len(names), names)
  return names


def load_session():
  selected_session = st.session_state.selected_session
  print('load session', selected_session)
  if not selected_session:
    reset_session()
    return
  session_path = os.path.join(
      app_context.get_agent_folder(),
      st.session_state.demo_name,
      selected_session + '.session.json',
  )
  with open(session_path, 'r') as f:
    st.session_state.session = Session.model_validate_json(f.read())
    print('loaded session', selected_session)
  logs_path = session_path.replace('.session.json', '.logs.json')
  if os.path.exists(logs_path):
    with open(logs_path, 'r') as f:
      st.session_state.call_llm_spans = json.load(f)
  else:
    st.session_state.call_llm_spans = {}
    st.toast('No logs found for the session.')


def reset_session():
  print('reset session')
  st.session_state.session = app_context.get_session_service().create()
  st.session_state.call_llm_spans = {}
  build_empty_state(app_context.get_root_agent(), st.session_state.session)


# Fills context dict with the keys that the instructions need.
def build_empty_state(agent, session):
  if not agent or not isinstance(agent, Agent):
    return
  if isinstance(agent.instruction, str):
    for key in re.findall(r'{([\w]+)}', agent.instruction):
      if key not in session.state:
        session.state[key] = ''
  for child in agent.children:
    build_empty_state(child, session)


def import_agent_module(reload=False):
  # The following line is needed to make sure the agent folder is in sys.path.
  app_context.get_agent_folder()
  demo_name = st.session_state.demo_name
  envs.load_dotenv_for_agent(demo_name, app_context.get_agent_folder())
  demo_modules = app_context.get_demo_modules()
  if reload:
    importlib.reload(demo_modules[demo_name].agent)
  else:
    demo_modules[demo_name] = importlib.import_module(demo_name)
  logger.info('Demo loaded: %s', demo_name)


# TODO: temporary for stripping out parts with bytes data
def strip_bytes_data(session):
  for event in session.events:
    event.content.parts = [
        part for part in event.content.parts if not part.inline_data
    ]
    event.actions.artifact_delta = None
  return session
