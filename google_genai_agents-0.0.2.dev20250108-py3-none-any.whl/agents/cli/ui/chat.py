import io
import mimetypes
import re
import time
import types
from datetime import datetime

import streamlit as st
from google.genai import types as genai_types
from PIL import Image
from ui import app_context
from ui import event_dialog


def show_event_dialog(event_index):
  st.session_state.event_dialog_index = event_index
  event_dialog.show()


# Uses fragment so button clicks won't cause full page rerun.
@st.fragment
def render_avatar(author, event_index, part_index):
  avatar = '👤' if author == 'user' else '🤖'
  inital = (
      ''.join(x[0] for x in author.split('_'))[:2].upper()
      if author != 'user' and author != 'root_agent'
      else ''
  )
  st.button(
      inital,
      icon=avatar,
      key=f'avatar_{event_index}_{part_index}',
      help=author,
      on_click=show_event_dialog,
      args=(event_index,),
  )


# Uses fragment so button clicks won't cause full page rerun.
@st.fragment
def render_part_button(event_index, part_index):
  event = st.session_state.session.events[event_index]
  part = event.content.parts[part_index]
  if part.function_call:
    title = f'⚡ {part.function_call.name}'
    with st.popover(title):
      st.button(
          'Details',
          key=f'details_{event_index}_{part_index}',
          on_click=show_event_dialog,
          args=(event_index,),
      )
      st.write(part.function_call.args)
  elif part.function_response:
    icon = '⏳' if event.actions.pending else '✔️'
    title = f'{icon} {part.function_response.name}'
    with st.popover(title):
      st.button(
          'Details',
          key=f'details_{event_index}_{part_index}',
          on_click=show_event_dialog,
          args=(event_index,),
      )
      st.write(part.function_response.response)
      if event.actions.state_delta:
        st.write('Updated context:')
        st.write(event.actions.state_delta)
      if event.actions.artifact_delta:
        st.write('Updated artifact:')
        st.write(event.actions.artifact_delta.keys())


last_fc_container = None
last_fc_author = None


def render_content(event_index, author, content):
  global last_fc_container
  global last_fc_author
  for part_index, part in enumerate(content.parts):
    if part.function_call or part.function_response:
      if not last_fc_container or last_fc_author != author:
        last_fc_author = author
        chat_row = st.container(key=f'chat_row_{event_index}_{part_index}')
        with chat_row:
          render_avatar(author, event_index, part_index)
          last_fc_container = st.container(key=f'row_layout_fc_{event_index}')
      with last_fc_container:
        render_part_button(event_index, part_index)
    else:
      last_fc_container = None
      last_fc_author = None
      # Sometime the model returns '\n' and it messes up the UI.
      if part.text and not part.text.strip():
        continue
      chat_row = st.container(key=f'chat_row_{event_index}_{part_index}')
      with chat_row:
        render_avatar(author, event_index, part_index)
        with st.container():
          st.write(transform_part(part))


def transform_part(part):
  if part.text:
    return part.text.strip()
  if part.inline_data:
    if part.inline_data.mime_type.startswith('image/'):
      return Image.open(io.BytesIO(part.inline_data.data))
    elif part.inline_data.mime_type.startswith('text/'):
      return 'Available file: [File Uploaded]'


def extract_code_block(text: str):
  """Returns: the first code block in the model message and truncate everything after it."""
  pattern = re.compile(
      (
          r'(?P<prefix>.*?)```(tool_code|python)\n'
          '(?P<code>.*?)\n```(?P<suffix>.*?)$'
      ).encode(),
      re.DOTALL,
  )
  pattern_match = pattern.search(text.encode())
  if pattern_match is None:
    return text, None

  prefix = pattern_match.group('prefix').decode()
  code = pattern_match.group('code').decode()
  return prefix, code


text_column = None
# function calling container that can show multiple function calls


def render_events(index_range):
  global text_column
  session = st.session_state.session

  for i in index_range:
    event = session.events[i]

    if not event.partial:
      text_column = None
    if not event.is_final_response() and not event.code_execution_event_type:
      render_content(i, event.author, event.content)
    elif event.code_execution_event_type:
      col1, col2 = st.columns([10, 90], vertical_alignment='top')
      text_column = col2
      with col1:
        render_avatar(event.author, i, 0)
      with col2:
        for raw_part in event.content.parts:
          part = transform_part(raw_part)
          if event.content.role == 'model':
            prefix_str, code_str = extract_code_block(part)
            if prefix_str:
              st.write(prefix_str)
              part = part.removeprefix(prefix_str)
          if event.code_execution_event_type == 'data':
            with st.expander(
                label='Loaded Data',
                expanded=True,
                icon='🗄️',
            ):
              st.write(part)
          elif part:
            with st.expander(
                label='Generated Code'
                if event.content.role == 'model'
                else 'Code Execution Result',
                expanded=False,
                icon='💻',
            ):
              st.write(part)
    else:
      render_content(i, event.author, event.content)


# Merges all partial text streams into a single embedded text stream.
def transform_stream(stream):
  def text_stream(event):
    yield event.content.parts[0].text
    while True:
      try:
        event = next(stream)
        yield event.content.parts[0].text
        if not event.partial:
          break
      except StopIteration:
        break

  while True:
    try:
      event = next(stream)
      if event.content and event.partial:
        yield text_stream(event)
      else:
        yield event
    except StopIteration:
      break


def run_prompt(prompt: str):
  session = st.session_state.session
  parts = []
  if st.session_state[st.session_state.file_uploader_key]:
    uploaded_files = st.session_state[st.session_state.file_uploader_key]
    # Uses a different key to clear the file uploader.
    st.session_state.file_uploader_key = str(time.time())
    for file in uploaded_files:
      mime_type, _ = mimetypes.guess_type(file.name)
      parts.append(
          genai_types.Part(
              inline_data=genai_types.Blob(
                  mime_type=mime_type, data=file.read()
              )
          )
      )
  parts.append(genai_types.Part(text=prompt))
  content = genai_types.Content(role='user', parts=parts)

  session_length = len(session.events)
  render_content(session_length, 'user', content)

  with st.spinner('Running...'):
    events = app_context.get_runner().run(
        session=session, new_message=content, stream=st.session_state.streaming
    )
    # print('**DEBUG** events: ', list(events))
    for event in transform_stream(events):
      if isinstance(event, types.GeneratorType):
        st.write_stream(event)
      else:
        render_events(
            range(len(session.events) - 1, len(session.events)),
        )
  # Rerun the page to reduce the chance of phantom elements.
  st.rerun()


def rerun_session():
  session = st.session_state.session
  old_events = session.events
  # We only clear the events and event logs, but keep the session context.
  session.events = []
  st.session_state.call_llm_spans = {}
  for event in old_events:
    if event.content and event.author == 'user':
      print(f'Rerun session: {event.content.parts[0].text}')
      run_prompt(event.content.parts[0].text)


def render_chat():
  if not st.session_state.demo_name:
    return
  session = st.session_state.session
  root_agent = app_context.get_root_agent()

  session.state['_time'] = str(datetime.now())
  if not session.events and root_agent.greeting_prompt:
    # new_message=None triggers the greeting prompt.
    events = list(
        app_context.get_runner().run(
            session=session, new_message=None, stream=st.session_state.streaming
        )
    )

  # TODO: enable this once fixed
  # if st.session_state.rerun_session:
  #   rerun_session()
  # else:
  #   render_events(range(len(session.events)))

  render_events(range(len(session.events)))

  prompt = st.chat_input('Say something')
  if prompt:
    run_prompt(prompt)
