# Agent Framework Developer Guide

This guide is for developers who want to contribute to the Agent Framework. You
don't have to read this if you just want to build an agent with the framework.

### General

*   Use **relative imports** for the packages and modules in the Agent
    Framework, aka in `src/agents` folder.
*   Update dependencies in `pyproject.toml`.
*   To debug in VS Code, use `Run and Debug` function. See
    [screenshot](https://screenshot.googleplex.com/7RJAop5vTcSzzhZ)

### Debug

#### Logging

In code, do the following:

```python
import logging

logger = logging.getLogger(__name__)

# ...

# prefer using lazy format, instead of f-string, which is eagerly calcualted.
logger.info("User's name: %s, email: %s", name, email)
```

Check the logs with the following command in system temp folder, e.g.
`/tmp/agent_logs` folder (the path should be printed as yellow at log setup
time, [screenshot](https://screenshot.googleplex.com/3gJRu8xxiSBT35B)):

```bash
tail -F /tmp/agent_logs/agent.debug.latest.log
```

### Testing
Testing guideline
*   Right now, we focus on integration(black box) testing.
*   Run all tests before you submit your code.
*   Add tests if it's not covered by existing tests.
*   Try to re-use existing agents for your tests. Only add new agents if the existing agents doesn't meet your needs.
*   Follow conventions that established by other tests.

#### Instructions for running tests:
run from project root dir(google3/experimental/genai/python/agents):
To run all tests,
```pytest tests/integration/```

To run one single test file:
```pytest tests/integration/test_multi_agent.py```

To run one single test method:
```pytest tests/integration/test_multi_agent.py::test_eval_agent```

(More details:
https://docs.google.com/document/d/1ecLhizMMwKdlNcRHQPboeOmRJIsHLmz1v0mBX6tqYA8/edit?tab=t.0#heading=h.by0zp5tdp0uu)

#### VS Code Setup

KEY features:

*   Auto-sort imports following google's style.
*   Auto-format on save following google's style.
*   Auto-complete for import namespaces, functions, parameters, etc.
*   Type hints.
*   Lint errors about type-mismatch, style, and other common mistakes.
*   Debugger: F5, F10 for step-by-step run.
*   Works on both gMac and Cloudtop.

TIP: this is my current setup after tuning for sometime, hoping to make it
closer to external developers. We want to polish developer experience over the
time, as well. Feel free to suggest and improve down the road.

##### Install VS Code

*   go/vscode/install
*   Google-specific extensions:
    *   go/vscode-google3
    *   go/fig-vscode

##### Start VS Code

Use `experimental/genai/python/agents` as workspace folder.

```bash
g4d -f G4_CLIENT
code experimental/genai/python/agents
```

##### Install Extensions

*   `.vscode/extensions.json` lists all recommended extension, they should
    appear in the
    [recommended section](https://screenshot.googleplex.com/6zm7UZSsYV6guid) in
    VS Code.
*   Especially remember to install
    [Gemini Code Assist + Google Cloud Code](https://marketplace.visualstudio.com/items?itemName=GoogleCloudTools.cloudcode),
    you can use `cloud-llm-preview1` as project in config.

##### User Settings

NOTE: I've configured all necessary settings in the workspace settings:
google3/experimental/genai/python/agents/.vscode/settings.json. Just in case, I
missed anything, below is my User Setting. When both configured, workspace
setting takes precedence.

```json
{
    "[jsonc]": {
        "editor.defaultFormatter": "vscode.json-language-features",
        "editor.formatOnSave": true
    },
    "[python]": {
        "editor.defaultFormatter": "ms-python.black-formatter",
        "editor.formatOnSave": true,
        "editor.formatOnSaveMode": "modifications",
        "editor.formatOnType": false
    },
    "black-formatter.args": [
        "--pyink-indentation=2",
        "--pyink-use-majority-quotes",
        "--line-length=80"
    ],
    "black-formatter.path": [
        "${env:HOME}/dev-tools/py_tools/bin/pyink"
    ],
    "cloudcode.duetAI.project": "cloud-llm-preview1",
    "cloudcode.project": "cloud-llm-preview1",
    "diffEditor.codeLens": true,
    "editor.defaultFormatter": "ms-python.black-formatter",
    "editor.insertSpaces": true,
    "editor.rulers": [
        80,
        120
    ],
    "editor.tabSize": 2,
    "explorer.autoReveal": true,
    "explorer.confirmDelete": false,
    "explorer.confirmDragAndDrop": false,
    "explorer.excludeGitIgnore": true,
    "fig.openFileIn": "codeEditor",
    "git.confirmSync": false,
    "git.enableSmartCommit": true,
    "git.openRepositoryInParentFolders": "always",
    "notebook.defaultFormatter": "ms-python.black-formatter",
    "pylint.args": [
        "--rcfile=${env:HOME}/dev-tools/google-styleguide/pylintrc"
    ],
    "pylint.path": [
        "/usr/bin/gpylint"
    ],
    "python.analysis.autoImportCompletions": true,
    "python.analysis.autoSearchPaths": false,
    "python.analysis.inlayHints.functionReturnTypes": true,
    "python.analysis.inlayHints.pytestParameters": true,
    "python.analysis.typeCheckingMode": "basic"
}
```

### Build wheel package

To build a new snapshot wheel package,

1.  Change `__version__` in
    google3/experimental/genai/python/agents/src/agents/__init__.py file. Use
    the current date after `dev`, e.g. `0.1.0.dev20241114`

1.  Run below command and the built wheel file will be in `dist/` folder:

    ```bash
    flit build
    ```

1.  Create a CL and check in.

### Deploy FastAPI Server

Under construction. Do not follow yet.

```
gcloud run deploy --source .
```

## Misc Topics

### How to connect to BigQuery in Agent

```bash
# Install bigquery package
pip install google-cloud-bigquery
# The module has to be installed to fix import error
pip install google-cloud-aiplatform
```

To access BigQuery, ensure you have "BigQuery Admin" permission. If you are not
using Vertex API, run the following:

```bash
gcloud auth login --no-launch-browser --update-adc
gcloud auth application-default set-quota-project [YOUR_PROJECT]
```

### How to set up Postgresql to store session for Agent Framework.

Set up docker

```bash
# Pull the latest Postgres container image to local image repository.
# https://hub.docker.com/_/postgres

docker pull postgres:latest

# Run a docker named `my-postgres` in detach mode with several Postgres DB environment variables and a persistent volume. Forwards traffice sent to port `5532` on host machine to port `5432` inside the container, which is the default port PostgreSQL listens.

docker run --name my-postgres -d -e POSTGRES_DB=agent  -e POSTGRES_USER=agent  -e POSTGRES_PASSWORD=agent  -e PGDATA=/var/lib/postgresql/data/pgdata -v pgvolume:/var/lib/postgresql/data -p 5532:5432 postgres
```

Verify DB connection

```bash
# Install psql client.
sudo apt install postgresql-client

# Connect to `agent` db in localhost 5532 port with username `agent`.
psql -h localhost -p 5532 -U agent -d agent
```
Create PostgresSessionService with `db_url`

The db_url should be in the format of `postgresql://<username>:<password>@domain:port/<database_name>`

e.g:

```
session_service = PostgresSessionService(db_url="postgresql://agent:agent@localhost:5532/agent")
```

## Known Issues

<!--#include file="/experimental/genai/python/agents/_known_issues.md"-->
