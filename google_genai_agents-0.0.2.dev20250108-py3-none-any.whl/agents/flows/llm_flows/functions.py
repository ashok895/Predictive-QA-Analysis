"""Handles function callings for LLM flow."""

from google.genai import types

from ...agents.base_agent import InvocationContext
from ...events import Event
from ...telemetry import tracer
from ...tools.base_tool import BaseTool
from ...tools.base_tool import ToolContext


def has_async_function_calls(
    function_calls: list[types.FunctionCall],
    tools_dict: dict[str, types.Tool],
) -> bool:
  for function_call in function_calls:
    if tools_dict[function_call.name].type == 'async_function':
      return True
  return False


def handle_function_calls(
    invocation_context: InvocationContext,
    function_call_event: Event,
    tools_dict: dict[str, types.Tool],
) -> Event:
  """Calls the functions and returns the function response event."""

  agent = invocation_context.agent
  session = invocation_context.session
  function_calls = function_call_event.get_function_calls()

  function_response_events: list[Event] = []
  for function_call in function_calls:
    # TODO: refactor the option for passing in function_call_event_id via a
    #   public interface.
    tool_context = ToolContext(
        session=session,
        function_call_event_id=function_call_event.id,
        function_call_id=function_call.id,
    )
    tool = tools_dict[function_call.name]
    if tool.type == 'async_function':
      tool_context.actions.pending = True

    # do not use "args" as the variable name, because it is a reserved keyword
    # in python debugger.
    function_args = function_call.args or {}
    function_response = None
    # Calls before_tool_callback if it exists.
    if agent.before_tool_callback:
      function_response = agent.before_tool_callback(
          invocation_context, tool, function_args, tool_context
      )

    # Calls the tool if before_tool_callback does not exist or returns None.
    if not function_response:
      function_response = __call_tool(
          tool, args=function_args, tool_context=tool_context
      )

    # Calls after_tool_callback if it exists.
    if agent.after_tool_callback:
      function_response = agent.after_tool_callback(
          invocation_context, tool, function_args, tool_context, function_response
      )

    # Builds the function response event.
    function_response_event = __build_response_event(
        tool, function_response, tool_context, invocation_context
    )
    function_response_events.append(function_response_event)

  merged_event = Event.merge_parallel_function_response_events(
      function_response_events
  )
  return merged_event


def __call_tool(
    tool: BaseTool, args: dict[str, object], tool_context: ToolContext
) -> object:
  """Calls the tool."""
  with tracer.start_as_current_span(f'call_tool [{tool.name}]'):
    return tool.call(args=args, tool_context=tool_context)


def __build_response_event(
    tool: BaseTool,
    function_result: dict[str, object],
    tool_context: ToolContext,
    invocation_context: InvocationContext,
) -> Event:
  # Specs requires the result to be a dict.
  if not isinstance(function_result, dict):
    function_result = {'result': function_result}

  part_function_response = types.Part.from_function_response(
      name=tool.name, response=function_result
  )
  part_function_response.function_response.id = tool_context.function_call_id

  content = types.Content(
      role='user',
      parts=[part_function_response],
  )
  return Event(
      invocation_id=invocation_context.invocation_id,
      author=invocation_context.agent.name,
      content=content,
      actions=tool_context.actions,
      function_call_event_id=tool_context.function_call_event_id,
  )
