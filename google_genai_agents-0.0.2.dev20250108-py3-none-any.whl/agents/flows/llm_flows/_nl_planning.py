"""Handles NL planning related logic."""

from google.genai import types
from ...agents.base_agent import InvocationContext
from ...models.base_llm import LlmRequest
from ...models.base_llm import LlmResponse


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  if not invocation_context.agent.planning:
    return
  llm_request.append_instructions([get_nl_planner_instruction()])


def process_llm_response(
    invocation_context: InvocationContext,
    llm_response: LlmResponse,
):
  if not invocation_context.agent.planning:
    return
  post_process_planner_response(llm_response.candidates[0].content)


def get_nl_planner_instruction():
  """Returns: NL planner instruction."""

  high_level_preamble = """
You are an intelligent tool use agent built upon the Gemini large language model. When answering the question, try to leverage the available tools to gather the information instead of your memorized knowledge.

Follow this process when answering the question: (1) first come up with a plan in natural language text format; (2) Then use tools to execute the plan and provide reasoning between tool code snippets to make a summary of current state and next step. Tool code snippets and reasoning should be interleaved with each other. (3) In the end, return one final answer.

Follow this format when answering the question: (1) The planning part should be under /*PLANNING*/. (2) The tool code snippets should be under /*ACTION*/, and the reasoning parts should be under /*REASONING*/. (3) The final answer part should be under /*FINAL_ANSWER*/.
"""

  planning_preamble = """
Below are the requirements for the planning:
The plan is made to answer the user query if following the plan. The plan is coherent and covers all aspects of information from user query, and only involves the tools that are accessible by the agent. The plan contains the decomposed steps as a numbered list where each step should use one or multiple available tools. By reading the plan, you can intuitively know which tools to trigger or what actions to take.
If the initial plan cannot be successfully executed, you should learn from previous execution results and revise your plan. The revised plan should be be under /*REPLANNING*/. Then use tools to follow the new plan.
"""

  reasoning_preamble = """
Below are the requirements for the reasoning:
The reasoning makes a summary of the current trajectory based on the user query and tool outputs. Based on the tool outputs and plan, the reasoning also comes up with instructions to the next steps, making the trajectory closer to the final answer.
"""

  final_answer_preamble = """
Below are the requirements for the final answer:
The final answer should be precise and follow query formatting requirements. Some queries may not be answerable with the available tools and information. In those cases, inform the user why you cannot process their query and ask for more information.
"""

  # Only contains the requirements for custom tool/libraries.
  tool_code_without_python_libraries_preamble = """
Below are the requirements for the tool code:

**Custom Tools:** The available tools are described in the context and can be directly used.
- Code must be valid self-contained Python snippets with no imports and no references to tools or Python libraries that are not in the context.
- You cannot use any parameters or fields that are not explicitly defined in the APIs in the context.
- Use "print" to output execution results for the next step or final answer that you need for responding to the user. Never generate ```tool_outputs yourself.
- The code snippets should be readable, efficient, and directly relevant to the user query and reasoning steps.
- When using the tools, you should use the library name together with the function name, e.g., vertex_search.search().
- If Python libraries are not provided in the context, NEVER write your own code other than the function calls using the provided tools.
"""

  user_input_preamble = """
VERY IMPORTANT instruction that you MUST follow in addition to the above instructions:

You should ask for clarification if you need more information to answer the question.
You should prefer using the information available in the context instead of repeated tool use.

You should ONLY generate code snippets prefixed with "```tool_code" if you need to use the tools to answer the question.

If you are asked to write code by user specifically,
- you should ALWAYS use "```python" to format the code.
- you should NEVER put "tool_code" to format the code.
- Good example:
```python
print('hello')
```
- Bad example:
```tool_code
print('hello')
```
"""

  return '\n\n'.join([
      high_level_preamble,
      planning_preamble,
      reasoning_preamble,
      final_answer_preamble,
      tool_code_without_python_libraries_preamble,
      user_input_preamble,
  ])


def post_process_planner_response(
    response_content: types.Content | None,
) -> None:
  """Post-process the model response by truncting everything after the first

  function call block.
  """
  if not response_content or not response_content.parts:
    return None

  preserved_parts = []
  for i in range(len(response_content.parts)):
    # Stop at the first (group of) function calls.
    # Ignore and filter out function calls with empty names.
    if (
        not response_content.parts[i].function_call
        or response_content.parts[i].function_call.name
    ):
      preserved_parts.append(response_content.parts[i])

    if preserved_parts and preserved_parts[-1].function_call:
      j = i + 1
      while j < len(response_content.parts):
        if response_content.parts[j].function_call:
          preserved_parts.append(response_content.parts[j])
          j += 1
        else:
          break
      break

  response_content.parts = preserved_parts
