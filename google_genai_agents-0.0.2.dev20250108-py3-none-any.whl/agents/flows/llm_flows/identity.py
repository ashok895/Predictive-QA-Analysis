"""Gives the agent identity from the framework."""

from ...agents.base_agent import InvocationContext
from ...models.base_llm import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  agent = invocation_context.agent
  si = [f'You are an agent. Your internal name is "{agent.name}".']
  if agent.description:
    si.append(f' The description about you is "{agent.description}"')
  llm_request.append_instructions(si)
