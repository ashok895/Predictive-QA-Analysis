"""Builds the contents for the LLM request."""

from google.genai import types

from ...agents.base_agent import InvocationContext
from ...events import Event
from ...models.base_llm import LlmRequest


def process_llm_request(
    invocation_context: InvocationContext,
    llm_request: LlmRequest,
):
  llm_request.contents = _get_contents(
      invocation_context.session.events, invocation_context.agent.name
  )


def _rearrange_events_for_async_function_responses_in_history(
    events: list[Event],
) -> list[Event]:
  """Rearrange the async function_response events in the history."""

  function_response_events_dict: dict[str, list[Event]] = {}
  for event in events:
    if event.get_function_responses():
      function_call_event_id: str = event.function_call_event_id  # type: ignore
      function_response_events = function_response_events_dict.get(
          function_call_event_id, []
      )
      function_response_events.append(event)
      function_response_events_dict[function_call_event_id] = (
          function_response_events
      )

  result_events: list[Event] = []
  for event in events:
    if event.get_function_responses():
      # function_response should be handled together with function_call below.
      continue
    elif event.get_function_calls():
      function_call_event_id = event.id
      function_response_events = function_response_events_dict.get(
          function_call_event_id, []
      )
      if not function_response_events:
        raise ValueError(
            'No matching function_response event found for id:'
            f' {function_call_event_id}'
        )
      result_events.append(event)
      if len(function_response_events) == 1:
        result_events.append(function_response_events[0])
      else:  # Merge all async function_response as one response event
        result_events.append(
            Event.merge_async_function_response_events(function_response_events)
        )
      continue
    else:
      result_events.append(event)

  return result_events


def _rearrange_events_for_latest_function_response(
    events: list[Event],
) -> list[Event]:
  """Rearrange the events for the latest function_response.

  If the latest function_response is for an async function_call, all events
  bewteen the initial function_call and the latest function_response will be
  removed.
  """
  if not events[-1].get_function_responses():
    # No need to process, since the latest event is not fuction_response.
    return events

  function_call_event_id = events[-1].function_call_event_id
  if events[-2].id == function_call_event_id:
    # The latest function_response is already matched
    return events

  reversed_function_response_events: list[Event] = []
  function_call_event_idx = -1
  for revered_idx, event in enumerate(reversed(events)):
    if event.id == function_call_event_id:
      function_call_event_idx = len(events) - 1 - revered_idx
      break
    elif (
        event.get_function_responses()
        and event.function_call_event_id == function_call_event_id
    ):
      reversed_function_response_events.append(event)

  if function_call_event_idx == -1:
    raise ValueError(
        f'No function call event found for id: {function_call_event_id}'
    )

  result_events = events[: function_call_event_idx + 1]
  result_events.append(
      Event.merge_async_function_response_events(
          list(reversed(reversed_function_response_events))
      )
  )
  return result_events


def _get_contents(
    events: list[Event], agent_name: str = ''
) -> list[types.Content]:
  filtered_events = []
  # Filter the events, leaving the contents and the function calls and
  # responses from the current agent.
  for event in events:
    if event.is_greeting:
      # Does not include the greeting message because it results in a low
      # agent transfer rate.
      continue
    if event.content:
      # Filter out function calls and responses that belong to other agents.
      # Otherwise the current agent will hallucinate and call the function.
      # TODO: Handle the case if both text and function call/response are
      # present.
      if (
          agent_name
          and event.author != agent_name
          and event.author != 'user'
          and (event.get_function_calls() or event.get_function_responses())
      ):
        continue
      filtered_events.append(event)
  result_events = _rearrange_events_for_latest_function_response(
      filtered_events
  )
  result_events = _rearrange_events_for_async_function_responses_in_history(
      result_events
  )
  return [e.content for e in result_events]
