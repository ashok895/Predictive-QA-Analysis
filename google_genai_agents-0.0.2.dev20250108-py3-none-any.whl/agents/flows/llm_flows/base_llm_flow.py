import json
from types import ModuleType
from typing import Any
from typing import Generator

from google.genai import types
from opentelemetry import trace

from ...agents.base_agent import InvocationContext
from ...events import Event
from ...models.base_llm import LlmRequest
from ...models.base_llm import LlmResponse
from ...models.registry import LLMRegistry
from ...telemetry import tracer
from ..base_flow import BaseFlow
from . import functions


class BaseLlmFlow(BaseFlow):
  """A basic flow that calls the LLM in a loop until a final response is generated.

  This flow ends when it transfer to another agent.
  """

  def __init__(self):
    self.request_processors: list[ModuleType] = []
    self.response_processors: list[ModuleType] = []

  def __call__(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    while True:
      last_event = None
      for event in self.__run_one_step(invocation_context):
        last_event = event
        yield event
      if not last_event or last_event.is_final_response():
        break

      # Transfers to the new agent if requested.
      transfer_to_agent = last_event.actions.transfer_to_agent
      if transfer_to_agent:
        root_agent = invocation_context.agent.get_root_agent()
        agent_to_run = root_agent.find_agent(transfer_to_agent)
        yield from agent_to_run.run(invocation_context)
        break

  def __run_one_step(
      self,
      invocation_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    """One step means one LLM call."""
    agent = invocation_context.agent
    llm_request = LlmRequest(
        model=agent.resolved_model
        if isinstance(agent.resolved_model, str)
        else agent.resolved_model.model,
        config=agent.generate_content_config,
    )
    llm_request.append_tools(invocation_context.agent.tools)
    if agent.output_schema:
      llm_request.set_output_schema(agent.output_schema)

    # Runs processors.
    for processor in self.request_processors:
      processor.process_llm_request(invocation_context, llm_request)

    # Runs before_model_callback if it exists.
    if agent.before_model_callback:
      events = agent.before_model_callback(invocation_context, llm_request)
      if events:
        yield from events
      if invocation_context.end_invocation:
        return

    # Calls the LLM.
    # TODO: handle streaming.
    event_id = Event.new_id()
    llm_response = self._call_llm(event_id, invocation_context, llm_request)

    # Runs after_model_callback if it exists.
    if agent.after_model_callback:
      events = agent.after_model_callback(invocation_context, llm_response)
      if events:
        yield from events
      if invocation_context.end_invocation:
        return

    # Stops if there is no response.
    if not llm_response.candidates:
      return

    # Runs processors.
    for processor in self.response_processors:
      processor.process_llm_response(invocation_context, llm_response)

    # Builds the event.
    model_response_event = self._build_model_response_event(
        event_id, invocation_context, llm_request, llm_response
    )
    yield model_response_event

    # Handles function calls.
    if model_response_event.get_function_calls():
      yield functions.handle_function_calls(
          invocation_context, model_response_event, llm_request.tools_dict
      )

  @tracer.start_as_current_span('call_llm')
  def _call_llm(
      self,
      event_id: str,
      invocation_context: InvocationContext,
      llm_request: LlmRequest,
  ) -> LlmResponse:
    resolved_model = invocation_context.agent.resolved_model
    llm = (
        LLMRegistry.new_llm(resolved_model)
        if isinstance(resolved_model, str)
        else resolved_model
    )

    llm_responses = list(llm.generate_content(llm_request))

    # Sets the span attributes.
    span = trace.get_current_span()
    span.set_attribute('invocation_id', invocation_context.invocation_id)
    span.set_attribute('event_id', event_id)
    span.set_attribute(
        'llm_request',
        json.dumps(self.build_llm_request_for_trace(llm_request)),
    )
    span.set_attribute(
        'llm_response', llm_responses[0].model_dump_json(exclude_none=True)
    )
    return llm_responses[0]

  def _build_model_response_event(
      self,
      event_id: str,
      invocation_context: InvocationContext,
      llm_request: LlmRequest,
      llm_response: LlmResponse,
  ) -> Event:
    content = llm_response.get_content()
    if not content:
      content = types.Content(
          role='model',
          parts=[
              types.Part.from_text(
                  'Error: '
                  + llm_response.candidates[0].model_dump_json(
                      exclude_none=True
                  )
              )
          ],
      )

    model_response_event = Event(
        id=event_id,
        invocation_id=invocation_context.invocation_id,
        author=invocation_context.agent.name,
        content=content,
    )
    function_calls = model_response_event.get_function_calls()
    if function_calls and functions.has_async_function_calls(
        function_calls, llm_request.tools_dict
    ):
      model_response_event.actions.pending = True
    return model_response_event

  def build_llm_request_for_trace(
      self, llm_request: LlmRequest
  ) -> dict[str, Any]:
    # Some fields in LlmRequest are function pointers and can not be serialized.
    result = {
        'model': llm_request.model,
        'config': llm_request.config.model_dump(
            exclude_none=True, exclude='response_schema'
        ),
        'contents': [],
    }
    # We do not want to send bytes data to the trace.
    for content in llm_request.contents:
      parts = [part for part in content.parts if not part.inline_data]
      result['contents'].append(
          types.Content(role=content.role, parts=parts).model_dump(
              exclude_none=True
          )
      )
    return result
