import logging
from . import example_util
from .base_example_provider import BaseExampleProvider
from .example import Example

logger = logging.getLogger(__name__)

__all__ = [
    'BaseExampleProvider',
    'Example',
    'example_util',
]

try:
  from .vertex_example_store import VertexExampleStore

  __all__.append('VertexExampleStore')
except ImportError:
  logger.warning(
      'The Vertex private preview sdk for example store is not installed. If'
      ' you want to use the Vertex example store with agents, please install'
      ' it. If not, you can ignore this warning.'
  )
