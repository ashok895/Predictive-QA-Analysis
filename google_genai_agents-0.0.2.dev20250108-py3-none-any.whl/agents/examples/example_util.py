"""Utility functions for converting examples to a string that can be used in system instructions in the prompt."""

import logging
from typing import TYPE_CHECKING

from .base_example_provider import BaseExampleProvider
from .example import Example

if TYPE_CHECKING:
  from ..agents.agent import Agent
  from ..sessions.session import Session

logger = logging.getLogger(__name__)

# Constant parts of the example string
_EXAMPLES_INTRO = (
    "<EXAMPLES>\nBegin few-shot\nThe following are examples of user queries and"
    " model responses using the available python libraries.\n\n"
)
_EXAMPLES_END = (
    "End few-shot\nNow, try to follow these examples and complete the following"
    " conversation\n<EXAMPLES>"
)
_EXAMPLE_START = "EXAMPLE {}:\nBegin example\n"
_EXAMPLE_END = "End example\n\n"
_USER_PREFIX = "[user]\n"
_MODEL_PREFIX = "[model]\n"
_FUNCTION_CALL_PREFIX = "```tool_code\n"
_FUNCTION_CALL_SUFFIX = "))\n```\n"
_FUNCTION_RESPONSE_PREFIX = "```tool_outputs\n"
_FUNCTION_RESPONSE_SUFFIX = "\n```\n"


def convert_examples_to_text(examples: list[Example]) -> str:
  """Converts a list of examples to a string that can be used in a system instruction."""
  examples_str = ""
  for example_num, example in enumerate(examples):
    output = (
        f"{_EXAMPLE_START.format(example_num + 1)}{_USER_PREFIX}{example.input.parts[0].text}\n\n"
    )

    for content in example.output:
      role_prefix = _MODEL_PREFIX if content.role == "model" else _USER_PREFIX
      for part in content.parts:
        if part.function_call:
          args = []
          # Convert function call part to python-like function call
          for k, v in part.function_call.args.items():
            if isinstance(v, str):
              args.append(f"{k}='{v}'")
            else:
              args.append(f"{k}={v}")
          output += (
              f"{role_prefix}{_FUNCTION_CALL_PREFIX}{part.function_call.name}({', '.join(args)}){_FUNCTION_CALL_SUFFIX}"
          )
        # Convert function response part to json string
        elif part.function_response:
          output += f"{_FUNCTION_RESPONSE_PREFIX}{part.function_response.__dict__}{_FUNCTION_RESPONSE_SUFFIX}"
        elif part.text:
          output += f"{role_prefix}{part.text}\n"

    output += _EXAMPLE_END
    examples_str += output

  return f"{_EXAMPLES_INTRO}{examples_str}{_EXAMPLES_END}"


def _get_latest_message_from_user(session: "Session") -> str:
  """Gets the latest message from the user.

  Returns:
    The latest message from the user. If not found, returns an empty string.
  """
  events = session.events
  if not events:
    return ""

  event = events[-1]
  if event.author == "user" and not event.get_function_responses():
    if event.content.parts and event.content.parts[0].text:
      return event.content.parts[0].text
    else:
      logger.warning("No message from user for fetching example.")

  return ""


def build_example_si(agent: "Agent", session: "Session") -> str:
  """Builds the example string for the system instruction."""
  if not agent.examples:
    return ""

  last_message_from_user = _get_latest_message_from_user(session)
  if not last_message_from_user:
    return ""

  if isinstance(agent.examples, list):
    return convert_examples_to_text(agent.examples)
  if isinstance(agent.examples, BaseExampleProvider):
    prompt = _get_latest_message_from_user(session)
    return convert_examples_to_text(agent.examples.get_examples(prompt))

  logger.error("Invalid example configuration for agent: %s.", agent.name)
  return ""
