import logging

from google.genai import types
from pydantic import BaseModel
from pydantic import Field

from ..events import Event
from .base_artifact_service import BaseArtifactService
from .base_artifact_service import ListArtifactsResponse
from .base_artifact_service import ListArtifactVersionsResponse

logger = logging.getLogger(__name__)


class InMemoryArtifactService(BaseArtifactService, BaseModel):

  artifacts: dict[str, dict[str, list[types.Part]]] = Field(default_factory=dict)

  def save(
      self,
      session_id: str,
      filename: str,
      artifact: types.Part,
  ) -> None:
    if session_id not in self.artifacts:
      self.artifacts[session_id] = {}

    if filename not in self.artifacts[session_id]:
      self.artifacts[session_id][filename] = []

    self.artifacts[session_id][filename].append(artifact)

  def load(
      self, session_id: str, filename: str) -> types.Part | None:
    if not self.artifacts.get(session_id):
      return None

    if not self.artifacts[session_id].get(filename):
      return None

    return self.artifacts[session_id][filename][-1]

  def list(self, session_id: str) -> ListArtifactsResponse:
    response = ListArtifactsResponse()
    if not self.artifacts.get(session_id):
      return response

    return ListArtifactsResponse(filenames=list(self.artifacts[session_id].keys()))

  def delete(self, session_id: str, filename: str) -> None:
    if not self.artifacts.get(session_id):
      return None
    self.artifacts[session_id].pop(filename, None)

  def process_event(self, session_id: str, event: Event) -> None:
    logger.info(f'Process event: {event.id} for session {session_id}')

    if not self.artifacts.get(session_id):
      self.artifacts[session_id] = {}
    session_artifacts = self.artifacts[session_id]

    if event.actions:
      if event.actions.artifact_delta:
        for key, value in event.actions.artifact_delta.items():
          if not session_artifacts.get(key):
            session_artifacts[key] = []
          session_artifacts[key].append(value)

  def list_versions(
      self, session_id: str, filename: str) -> ListArtifactVersionsResponse:
    response = ListArtifactVersionsResponse()
    if not self.artifacts.get(session_id):
      return response

    versions = self.artifacts[session_id][filename]
    return ListArtifactVersionsResponse(versions=list(versions))
