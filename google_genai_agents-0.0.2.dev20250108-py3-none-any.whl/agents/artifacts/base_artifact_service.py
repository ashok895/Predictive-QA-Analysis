import abc

from google.genai import types
from pydantic import BaseModel

from ..events import Event


class ListArtifactsResponse(BaseModel):
  filenames: list[str] = []

class ListArtifactVersionsResponse(BaseModel):
  versions: list[types.Part] = []


class BaseArtifactService(abc.ABC):

  @abc.abstractmethod
  def save(
      self,
      session_id: str,
      filename: str,
      artifact: types.Part,
  ) -> None:
    """Saves an artifact."""
    pass

  @abc.abstractmethod
  def load(
      self, session_id: str, filename: str) -> types.Part | None:
    """Gets an artifact."""
    pass

  @abc.abstractmethod
  def list(self, session_id: str) -> ListArtifactsResponse:
    """Lists all the artifact filenames within a session."""
    pass

  @abc.abstractmethod
  def delete(self, session_id: str, filename: str) -> None:
    """Deletes an artifact."""
    pass

  @abc.abstractmethod
  def process_event(self, session_id: str, event: Event) -> None:
    """Processes an event to update artifacts."""
    pass

  @abc.abstractmethod
  def list_versions(
      self, session_id: str, filename: str) -> ListArtifactVersionsResponse:
    """Lists all the versions of an artifact."""
    pass
