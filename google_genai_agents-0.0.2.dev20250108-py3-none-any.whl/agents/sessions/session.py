from typing import Any

from pydantic import BaseModel
from pydantic import Field

from ..events import Event


class Session(BaseModel):
  # TODO: Makes this required.
  id: str = ''
  state: dict[str, Any] = Field(default_factory=dict)
  events: list[Event] = Field(default_factory=list)

  last_update_time: float = 0.0
