import logging
import uuid
from datetime import datetime
from typing import Any
from typing import Optional

from sqlalchemy import ForeignKey
from sqlalchemy import delete
from sqlalchemy import func
from sqlalchemy import select
from sqlalchemy.dialects import postgresql
from sqlalchemy.engine import Engine
from sqlalchemy.engine import create_engine
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.inspection import inspect
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import Session as DatabaseSessionFactory
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from sqlalchemy.orm import sessionmaker
from sqlalchemy.schema import MetaData
from sqlalchemy.types import UUID
from sqlalchemy.types import DateTime
from sqlalchemy.types import PickleType
from sqlalchemy.types import String
from tzlocal import get_localzone

from ..events import Event
from .base_session_service import BaseSessionService
from .base_session_service import GetSessionConfig
from .base_session_service import ListEventsConfig
from .base_session_service import ListEventsResponse
from .base_session_service import ListSessionsResponse
from .base_session_service import PendingEvent
from .session import Session

logger = logging.getLogger(__name__)

Base = declarative_base()

class StorageSession(Base):
    __tablename__ = "sessions"

    id: Mapped[str] = mapped_column(
        String, primary_key=True, default=lambda: str(uuid.uuid4())
    )

    context: Mapped[dict] = mapped_column(MutableDict.as_mutable(postgresql.JSONB), default={})

    create_time: Mapped[DateTime] = mapped_column(
        DateTime(), default=func.now()
    )
    update_time: Mapped[DateTime] = mapped_column(
        DateTime(), default=func.now(), onupdate=func.now()
    )

    storage_events: Mapped[list["StorageEvent"]] = relationship(
        "StorageEvent", back_populates="storage_session"
    )

    pending_events: Mapped[dict[str, list]] = mapped_column(MutableDict.as_mutable(postgresql.JSONB), default={})

    def __repr__(self):
      return f'<StorageSession(id={self.id}, update_time={self.update_time}, pending_events={self.pending_events})>'


class StorageEvent(Base):
    __tablename__ = "events"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id = mapped_column(ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False)

    invocation_id: Mapped[str] = mapped_column(String)
    author: Mapped[str] = mapped_column(String)
    timestamp: Mapped[DateTime] = mapped_column(
        DateTime(), default=func.now()
    )
    content: Mapped[str] = mapped_column(postgresql.JSONB)
    actions: Mapped[dict] = mapped_column(PickleType)

    storage_session: Mapped[StorageSession] = relationship(
        "StorageSession", back_populates="storage_events"
    )


class PostgresSessionService(BaseSessionService):

  def __init__(
    self,
    db_url: Optional[str] = None,
  ):
    """
    Args:
            db_url (Optional[str]): The database URL to connect to.
    """
    # 1. Create DB engine for db connection
    # 2. Create all tables based on schema
    # 3. Initialize all properies
    if db_url is None:
        raise ValueError("db_url can not be None")

    # Get the local timezone
    local_timezone = get_localzone()
    logging.info(f'Local timezone: {local_timezone}')

    self.db_engine: Engine = create_engine(db_url, connect_args={"options": f"-c timezone={local_timezone}"})
    self.metadata: MetaData = MetaData()
    self.inspector = inspect(self.db_engine)

    # DB session factory method
    self.DatabaseSessionFactory: sessionmaker[DatabaseSessionFactory] = sessionmaker(bind=self.db_engine)

    Base.metadata.drop_all(self.db_engine)  # Remove after code is stable
    Base.metadata.create_all(self.db_engine)

  def create(self,
      context: Optional[dict[str, Any]] = None,
      *,
      session_id: Optional[str] = None,
  ) -> Session:
    # 1. Build storage session object
    # 2. Add the object to the table
    # 3. Build the session object with generated id
    # 4. Return the session
    with self.DatabaseSessionFactory() as sessionFactory:
      storage_session = StorageSession(id=session_id, context=context or {})
      sessionFactory.add(storage_session)
      sessionFactory.commit()

      sessionFactory.refresh(storage_session)
      session = Session(id=str(storage_session.id), context=context or {}, last_update_time=storage_session.update_time.timestamp())
      return session
    return None

  def get(self, session_id: str, config: GetSessionConfig | None = None) -> Session:
    # 1. Get the storage session entry from session table
    # 2. Get all the events based on session id and filtering config
    # 3. Convert and return the session
    session: Session = None
    with self.DatabaseSessionFactory() as sessionFactory:
      storage_session = sessionFactory.get(StorageSession, session_id)
      if storage_session is None:
        return None

      storage_events = (
        sessionFactory.query(StorageEvent)
        .filter(StorageEvent.session_id == storage_session.id)
        .filter(StorageEvent.timestamp < config.after_timestamp if config else True)
        .limit(config.num_recent_events if config else None)
        .all()
      )

      # Convert storage session to session
      session = Session(
        id=session_id,
        state=storage_session.state,
        last_update_time=storage_session.update_time.timestamp(),
      )
      session.events = [Event(
        id=e.id, author=e.author, invocation_id=e.invocation_id,
        content=e.content,
        actions=e.actions,
        timestamp=e.timestamp.timestamp()) for e in storage_events]

    return session

  def list_sessions(self) -> ListSessionsResponse:
    with self.DatabaseSessionFactory() as sessionFactory:
      results = sessionFactory.scalars(select(StorageSession.id)).all()
      return ListSessionsResponse(session_ids=results)
    raise ValueError('Failed to retrieve sessions.')


  def delete(self, session_id: str) -> None:
    with self.DatabaseSessionFactory() as sessionFactory:
      stmt = delete(StorageSession).where(StorageSession.id == session_id)
      sessionFactory.execute(stmt)
      sessionFactory.commit()

  def append_event(self, session: Session, event: Event) -> Event:
    logger.info(f'Append event: {event} to session {session.id}')

    # 1. Check if timestamp is stale
    # 2. Update session attributes based on event config
    # 3. Handle pending events case
    # 4. Store event to table
    with self.DatabaseSessionFactory() as sessionFactory:
      storage_session = sessionFactory.get(StorageSession, session.id)

      if storage_session.update_time.timestamp() > session.last_update_time:
        raise ValueError(f'Session last_update_time {session.last_update_time} is later than the upate_time in storage {storage_session.update_time}')

      if event.actions:
        if event.actions.state_delta:
          context_to_update = storage_session.state
          context_to_update.update(event.actions.state_delta)
          storage_session.state = context_to_update

        # TODO: Handle pending events
        # if event.get_function_calls() and event.actions.pending:
        #   storage_session.pending_events[event.id] = []

        # if event.get_function_responses() and not event.actions.pending:
        #   storage_session.pending_events.pop(event.function_call_event_id, None)

      encoded_content = event.content.model_dump(exclude_none=True)
      storage_event = StorageEvent(id=event.id,
        invocation_id=event.invocation_id,
        author=event.author,
        content=encoded_content,
        actions=event.actions,
        session_id=session.id,
        timestamp=datetime.fromtimestamp(event.timestamp))

      sessionFactory.add(storage_event)

      sessionFactory.commit()
      sessionFactory.refresh(storage_session)

      # Update timestamp with commit time
      session.last_update_time = storage_session.update_time.timestamp()

    # Also update the in-memory session
    super().append_event(session, event)
    return event

  def list_events(
      self, session_id: str, config: ListEventsConfig
  ) -> ListEventsResponse:
    pass

  # TODO: Implement this
  def list_pending_events(self, session_id: str) -> list[PendingEvent]:
    pass
