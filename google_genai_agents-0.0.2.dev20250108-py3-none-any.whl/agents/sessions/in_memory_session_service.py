import time
import uuid
from typing import Any, Optional

from ..events import Event
from .base_session_service import (
    BaseSessionService,
    GetSessionConfig,
    ListEventsConfig,
    ListEventsResponse,
    ListSessionsResponse
)
from .session import Session


class InMemorySessionService(BaseSessionService):
  sessions: dict[str, Session] = {}

  def create(
      self,
      context: Optional[dict[str, Any]] = None,
      *,
      session_id: Optional[str] = None,
  ) -> Session:
    session_id = (
        session_id.strip()
        if session_id and session_id.strip()
        else str(uuid.uuid4())
    )
    session = Session(id=session_id, context=context or {}, last_update_time=time.time())
    self.sessions[session_id] = session
    return session

  def exists(self, session_id: str) -> bool:
    return session_id in self.sessions

  def get(
      self, session_id: str, config: GetSessionConfig | None = None
  ) -> Session:
    session = self.sessions.get(session_id)
    if config:
      if config.num_recent_events:
        session.events = session.events[-config.num_recent_events :]
      elif config.after_timestamp:
        i = len(session.events) - 1
        while i >= 0:
          if session.events[i].timestamp < config.after_timestamp:
            break
          i -= 1
        if i >= 0:
          session.events = session.events[i:]
    return session

  def list_sessions(self) -> ListSessionsResponse:
    return ListSessionsResponse(session_ids=list(self.sessions))

  def delete(self, session_id: str) -> None:
    if session_id in self.sessions:
      self.sessions.pop(session_id)

  def append_event(self, session: Session, event: Event) -> Event:
    super().append_event(session, event)
    session.last_update_time = event.timestamp
    return event

  def list_events(
      self, session_id: str, config: ListEventsConfig
  ) -> ListEventsResponse:
    raise NotImplementedError()
