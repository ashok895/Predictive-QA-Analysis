"""Provides data for the agent."""

from typing import Any

from llama_index.core import SimpleDirectoryReader, VectorStoreIndex
from llama_index.core.base.base_retriever import BaseRetriever
from pydantic import Field, model_validator

from .llama_index_retrieval import LlamaIndexRetrieval


class FilesRetrieval(LlamaIndexRetrieval):

  retriever: BaseRetriever = Field(init=False)
  input_dir: str

  @model_validator(mode='before')
  @classmethod
  def create_retriever(cls, data: dict[str, Any]) -> dict[str, Any]:

    input_dir = data['input_dir']
    print(f'Loading data from {input_dir}')
    retriever = VectorStoreIndex.from_documents(
        SimpleDirectoryReader(input_dir).load_data()
    ).as_retriever()
    data['retriever'] = retriever
    return data
