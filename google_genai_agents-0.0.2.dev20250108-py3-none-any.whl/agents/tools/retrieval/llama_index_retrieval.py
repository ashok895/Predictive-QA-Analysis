"""Provides data for the agent."""

from typing import Any
from typing import TYPE_CHECKING

from ...events import Event
from ..base_tool import ToolContext
from .base_retrieval_tool import BaseRetrievalTool

if TYPE_CHECKING:
  from llama_index.core.base.base_retriever import BaseRetriever


class LlamaIndexRetrieval(BaseRetrievalTool):

  retriever: 'BaseRetriever'

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Event:
    return self.retriever.retrieve(args['query'])[0].text
