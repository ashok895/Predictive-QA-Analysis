"""A retrieval tool that uses Vertex RAG to retrieve data."""

from typing import Any

from vertexai.preview import rag

from ..base_tool import ToolContext
from . import BaseRetrievalTool


class VertexRagRetrieval(BaseRetrievalTool):
  rag_corpus_name: str
  rag_file_ids: list[str] = None

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:
    response = rag.retrieval_query(
        rag_resources=[
            rag.RagResource(
                rag_corpus=self.rag_corpus_name,
                rag_file_ids=self.rag_file_ids,
            )
        ],
        text=args['query'],
    )
    return (
        f'No matching result found in the {self.rag_corpus_name}'
        if not response.contexts.contexts
        else response.contexts.contexts[0].text
    )
