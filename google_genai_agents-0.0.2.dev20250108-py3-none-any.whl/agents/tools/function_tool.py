import inspect
from typing import Any
from typing import Callable
from typing import Optional

from google.genai import types
from pydantic import Field
from pydantic import model_validator
from termcolor import cprint

from ._automatic_function_calling_util import build_function_declaration
from .base_tool import BaseTool
from .base_tool import ToolContext


class FunctionTool(BaseTool):

  name: str = Field(init=False)
  description: Optional[str] = Field(default='')
  type: str = Field('function', init=False, frozen=True)
  func: Callable[..., Any]

  @model_validator(mode='before')
  @classmethod
  def populate_name(cls, data: Any) -> Any:
    data['name'] = data['func'].__name__
    data['description'] = data['func'].__doc__
    return data

  def get_declaration(self) -> types.FunctionDeclaration:
    function_decl = types.FunctionDeclaration.model_validate(
        build_function_declaration(
            False,
            self.name,
            self.description,
            self.func,
            # The model doesn't understand the function context.
            ignore_params=['tool_context'],
        )
    )

    return function_decl

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:
    args_to_call = args.copy()
    signature = inspect.signature(self.func)
    if 'tool_context' in signature.parameters:
      args_to_call['tool_context'] = tool_context
    return self.func(**args_to_call) or {}

  @staticmethod
  def from_function(func: Callable) -> 'FunctionTool':
    return FunctionTool(description=func.__doc__, func=func)
