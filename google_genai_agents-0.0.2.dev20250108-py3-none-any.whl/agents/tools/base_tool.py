import abc
from types import MappingProxyType
from typing import Any
from typing import Optional

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict

from ..events import EventActions
from ..sessions import Session


class ToolContext:

  def __init__(
      self,
      session: Session,
      function_call_event_id: str | None = None,
      function_call_id: str | None = None,
  ):
    self.actions = EventActions()
    self._session = session
    self.function_call_event_id = function_call_event_id
    self.function_call_id = function_call_id

  def get_state(self) -> dict[str, Any]:
    # Returns a read-only view of the context.
    return MappingProxyType(self._session.state)

  def get_artifact(self, key: str) -> types.Part:
    # Returns a read-only view of the context.
    return self._session.get_artifact(key)


class BaseTool(BaseModel):
  model_config = ConfigDict(
      arbitrary_types_allowed=True,
  )

  name: str
  type: str
  description: Optional[str] = None

  @abc.abstractmethod
  def get_declaration(self) -> types.FunctionDeclaration:
    pass

  @abc.abstractmethod
  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:
    """Call the tool."""
    pass
