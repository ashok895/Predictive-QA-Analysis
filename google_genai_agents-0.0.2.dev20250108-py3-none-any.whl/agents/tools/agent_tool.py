from typing import Any

from google.genai import types
from pydantic import Field, model_validator
from termcolor import cprint

from ..agents.agent import Agent
from ..events import Event
from . import _automatic_function_calling_util
from .base_tool import BaseTool, ToolContext


class AgentTool(BaseTool):

  name: str = Field(init=False)
  type: str = Field('agent', init=False, frozen=True)
  # TODO: Change this to BaseAgent.
  agent: Agent
  output_key: str | None = None
  skip_summarization: bool = False

  @model_validator(mode='before')
  @classmethod
  def populate_name(cls, data: Any) -> Any:
    data['name'] = data['agent'].name
    return data

  def get_declaration(self) -> types.FunctionDeclaration:
    if self.agent.input_schema:
      result = _automatic_function_calling_util.build_function_declaration(
          False, self.name, self.agent.description, self.agent.input_schema
      )
    else:
      result = types.FunctionDeclaration(
          parameters=types.Schema(
              type='OBJECT',
              properties={
                  'request': types.Schema(
                      type='STRING',
                  ),
              },
              required=['request'],
          ),
          description=self.agent.description,
          name=self.name,
      )
    result.name = self.name
    return result

  def call(
      self,
      *,
      args: dict[str, Any],
      tool_context: ToolContext,
  ) -> Any:
    if self.agent.input_schema:
      args = self.agent.input_schema.model_validate(args)
    else:
      args = args['request']
    cprint(f'Agent Tool: {self.name}({args})', 'green', attrs=['bold'])
    tool_result = self.agent.run_as_tool(
        args, input_context=tool_context.get_state()
    )
    if self.agent.output_schema:
      tool_result = tool_result.model_dump(exclude_none=True)
    if self.output_key:
      tool_context.actions.update_state(self.output_key, tool_result)
    return tool_result
