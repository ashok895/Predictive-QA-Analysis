from typing import Any

from google.genai import types
from pydantic import model_validator

from . import _automatic_function_calling_util
from .function_tool import FunctionTool


class LangchainTool(FunctionTool):
  """Use this class to wrap a langchain tool.

  If the original tool name and description are not suitable, you can override
  them in the constructor.
  """

  tool: Any

  def __init__(self, tool: Any, **data):
    data['tool'] = tool
    if data.get('name'):
      data['name'] = data.get('name')
    elif tool.name:
      data['name'] = tool.name
    else:
      raise ValueError('name is not defined in the tool.')
    if data.get('description'):
      data['description'] = data.get('description')
    elif tool.description:
      data['description'] = tool.description
    else:
      raise ValueError('description is not defined in the tool.')

    data['func'] = tool.run
    super().__init__(**data)

  @model_validator(mode='before')
  @classmethod
  def populate_name(cls, data: Any) -> Any:
    # Override this to not use function's signature name as it's
    # mostly "run" or "invoke" for thir-party tools.
    return data

  def get_declaration(self) -> types.FunctionDeclaration:
    """Build the function declaration for the tool."""
    from langchain.agents import Tool
    from langchain_core.tools import BaseTool

    # There are two types of tools:
    # 1. BaseTool: the tool is defined in langchain.tools.
    # 2. Other tools: the tool doesn't inherit any class but follow some
    #    conventions, like having a "run" method.
    if isinstance(self.tool, BaseTool):
      tool_wrapper = Tool(
          name=self.name,
          func=self.func,
          description=self.description,
      )
      function_declaration = _automatic_function_calling_util.build_function_declaration_for_langchain(
          False,
          self.name,
          self.description,
          tool_wrapper.func,
          tool_wrapper.args,
      )
      return function_declaration
    else:
      # Need to provide a way to override the function names and descriptions
      # as the original function names are mostly ".run" and the descriptions
      # may not meet users' needs.
      function_declaration = (
          _automatic_function_calling_util.build_function_declaration(
              False,
              self.name,
              self.description,
              self.tool.run,
          )
      )
      return function_declaration
