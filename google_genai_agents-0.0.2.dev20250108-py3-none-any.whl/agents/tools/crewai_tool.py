from typing import Any

from google.genai import types
from pydantic import model_validator

from . import _automatic_function_calling_util
from .function_tool import FunctionTool


class CrewaiTool(FunctionTool):
  """Use this class to wrap a CrewAI tool.

  If the original tool name and description are not suitable, you can override
  them in the constructor.
  """

  tool: Any

  def __init__(self, tool: Any, **data):
    data['tool'] = tool
    if data.get('name'):
      data['name'] = data.get('name')
    elif tool.name:
      # Right now, CrewAI tool name contains white spaces. White spaces are
      # not supported in our framework. So we replace them with "_".
      data['name'] = tool.name.replace(" ", "_").lower()
    else:
      raise ValueError('name is not defined in the tool.')
    if data.get('description'):
      data['description'] = data.get('description')
    elif tool.description:
      data['description'] = tool.description
    else:
      raise ValueError('description is not defined in the tool.')

    data['func'] = tool.run
    super().__init__(**data)

  @model_validator(mode='before')
  @classmethod
  def populate_name(cls, data: Any) -> Any:
    # Override this to not use function's signature name as it's
    # mostly "run" or "invoke" for thir-party tools.
    return data

  def get_declaration(self) -> types.FunctionDeclaration:
    """Build the function declaration for the tool."""
    print("self.tool.args_schema:", self.tool.args_schema)
    function_declaration = _automatic_function_calling_util.build_function_declaration_for_params_for_crewai(
        False,
        self.name,
        self.description,
        self.func,
        self.tool.args_schema.schema(),
    )
    print("function_declaration:", function_declaration)
    return function_declaration
