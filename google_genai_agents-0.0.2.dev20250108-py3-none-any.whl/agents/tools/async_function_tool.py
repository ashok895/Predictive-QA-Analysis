from pydantic import Field
from .function_tool import FunctionTool


class AsyncFunctionTool(FunctionTool):
  """A function tool that returns the result asynchronously."""

  type: str = Field('async_function', init=False, frozen=True)
