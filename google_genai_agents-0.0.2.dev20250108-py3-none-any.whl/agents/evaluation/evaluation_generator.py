import importlib

from agents.sessions import InMemorySessionService
from google.genai import types

from ..runners import Runner


class EvaluationGenerator:
  """Generates evaluation responses for agents."""

  @staticmethod
  def generate_responses(
      eval_dataset, agent_module_path, repeat_num=3, agent_name=None
  ):

    module_name = agent_module_path.split("/")[
        -1
    ]  # e.g., 'home_automation_agent'
    results = []
    # breakpoint()
    for _ in range(repeat_num):
      for data in eval_dataset:
        results.append(
            EvaluationGenerator._process_query(
                data, agent_module_path, agent_name
            )
        )

    return results

  @staticmethod
  def _process_query(data, module_name, agent_name=None):
    # Initialize session and agent module
    session_service = InMemorySessionService()
    session = session_service.create()

    # module_path = f"tests.integration.fixture.{module_name}"
    # module_path = f"samples.{module_name}"
    module_path = f"{module_name}"
    # breakpoint()
    agent_module = importlib.import_module(module_path)
    root_agent = agent_module.agent.root_agent
    runner = Runner(root_agent, session_service)

    # Reset agent state for each query
    reset_func = getattr(agent_module.agent, "reset_data", None)
    if callable(reset_func):
      reset_func()

    responses = data.copy()

    for index, eval_entry in enumerate(responses):
      response = None
      query = eval_entry["query"]
      content = types.Content(role="user", parts=[types.Part(text=query)])
      # Run the agent and collect responses
      turn_actual_tool_uses = []
      for event in runner.run(session=session, new_message=content):
        # TODO: handle intermediate response in the middle of the tool calls.
        # (this is rare but do happens.)
        if event.is_final_response():
          response = event.content.parts[0].text
        elif event.get_function_calls():
          for call in event.get_function_calls():
            turn_actual_tool_uses.append(
                {"tool_name": call.name, "tool_input": call.args}
            )
      responses[index]["actual_tool_use"] = turn_actual_tool_uses
      responses[index]["response"] = response

    return responses
