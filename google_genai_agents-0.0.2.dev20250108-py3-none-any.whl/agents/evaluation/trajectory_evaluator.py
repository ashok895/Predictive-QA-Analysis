import pandas as pd
from tabulate import tabulate


class TrajectoryEvaluator:
  """Evaluates tool trajectories for accuracy."""

  @staticmethod
  def evaluate(eval_dataset):
    results_df = pd.DataFrame(
        columns=[
            "query",
            "response",
            "actual_tool_use",
            "expected_tool_use",
            "tool_use_accuracy",
        ]
    )
    failures = []

    for conversation in eval_dataset:
      for row in conversation:
        new_row, failure = TrajectoryEvaluator._evaluate_row(row)
        results_df = pd.concat(
            [results_df, pd.DataFrame([new_row])], ignore_index=True
        )
        if failure:
          failures.append(failure)

    TrajectoryEvaluator._report_failures(failures)
    TrajectoryEvaluator._print_results(results_df)
  
    return results_df["tool_use_accuracy"].mean()

  @staticmethod
  def _evaluate_row(row):
    expected = row["expected_tool_use"]
    actual = row["actual_tool_use"]
    tool_use_accuracy = (
        1.0 if TrajectoryEvaluator._are_lists_equal(actual, expected) else 0.0
    )

    new_row = {
        "query": row["query"],
        "response": row["response"],
        "actual_tool_use": actual,
        "expected_tool_use": expected,
        "tool_use_accuracy": tool_use_accuracy,
    }
    failure = (
        None
        if tool_use_accuracy == 1.0
        else {"query": row["query"], "actual": actual, "expected": expected}
    )
    return new_row, failure

  @staticmethod
  def _are_lists_equal(list_a, list_b):
    def normalize_dict(d):
      return tuple(
          sorted(
              (k, normalize_dict(v) if isinstance(v, dict) else v)
              for k, v in d.items()
          )
      )

    normalized_a = sorted(
        [normalize_dict(d) for d in list_a], key=lambda x: str(x)
    )
    normalized_b = sorted(
        [normalize_dict(d) for d in list_b], key=lambda x: str(x)
    )
    return normalized_a == normalized_b

  @staticmethod
  def _report_failures(failures):
    if failures:
      print("Failures:")
      for failure in failures:
        print(f"""{{
                    "query": '{failure["query"]}',
                    "actual": {failure["actual"]},
                    "expected_tool_use": {failure["expected"]},
                }}""")

  @staticmethod
  def _print_results(results_df):
    print(tabulate(results_df, headers="keys", tablefmt="grid"))
