import logging

logger = logging.getLogger(__name__)

__all__ = ['AgentEvaluator']

try:
  from .agent_evaluator import AgentEvaluator

  __all__.append('AgentEvaluator')
except ImportError:
  logger.warning(
      'The Vertex[eval] sdk is not installed. If you want to use the Vertex'
      ' Evaluation with agents, please install it. If not, you can ignore this'
      ' warning.'
  )
