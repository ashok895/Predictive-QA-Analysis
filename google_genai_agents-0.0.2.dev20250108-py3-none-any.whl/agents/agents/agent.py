from functools import cached_property
import logging
from typing import Any
from typing import Callable
from typing import Generator
from typing import Union

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import model_validator

from ..artifacts import InMemoryArtifactService
from ..events import Event
from ..examples import BaseExampleProvider
from ..examples import Example
from ..flows.base_flow import BaseFlow
from ..flows.registry import FlowRegistry
from ..models.base_llm import BaseLlm
from ..models.base_llm import LlmRequest
from ..models.base_llm import LlmResponse
from ..sessions import InMemorySessionService
from ..telemetry import tracer
from ..tools.base_tool import BaseTool
from ..tools.base_tool import ToolContext
from .base_agent import BaseAgent
from .base_agent import InvocationContext

logger = logging.getLogger(__name__)


BeforeModelCallback = Callable[
    [InvocationContext, LlmRequest], Generator[Event, None, None] | None
]
AfterModelCallback = Callable[
    [InvocationContext, LlmResponse],
    Generator[Event, None, None] | None,
]
BeforeAgentCallback = Callable[
    [InvocationContext], Generator[Event, None, None] | None
]
AfterAgentCallback = Callable[
    [InvocationContext], Generator[Event, None, None] | None
]
BeforeToolCallback = Callable[
    [InvocationContext, BaseTool, dict[str, Any], ToolContext],
    dict | None,
]
AfterToolCallback = Callable[
    [InvocationContext, BaseTool, dict[str, Any], ToolContext, dict],
    None,
]
InstructionProvider = Callable[[InvocationContext], str]

ToolUnion = Callable | BaseTool

ExamplesUnion = list[Example] | BaseExampleProvider

FlowCallable = Callable[[InvocationContext], Generator[Event, None, None]]


class Agent(BaseAgent):
  """The LLM-based agent."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  model: str | BaseLlm = ''
  """The model to use for the agent.

  When not set, the agent will inherit the model from its parent agent.
  """

  instruction: str | InstructionProvider = ''
  """Instructions for the LLM model, guiding the agent's behavior."""

  global_instruction: str | InstructionProvider = ''
  """Instructions for all the children agents in the entire agent tree.
  Only allowd in root agent.
  You can use this instruction to set up a stable identify or personality across all child agents."""

  flow: str | BaseFlow | FlowCallable = 'single'
  children: list[BaseAgent] = []
  tools: list[ToolUnion] = []
  generate_content_config: types.GenerateContentConfig | None = None
  examples: ExamplesUnion | None = None
  greeting_prompt: str | None = None

  # If true, the agent will be instructed to make a plan and execute it step by
  # step. Default to false.
  planning: bool = False

  # If true, the agent will not be able to transfer the question to its sibling
  # agents. Default to false.
  disable_sibling_agent_transfer: bool = False

  input_schema: type[BaseModel] | None = None
  output_schema: type[BaseModel] | None = None

  before_model_callback: BeforeModelCallback | None = None
  """Called before the model is called.

  The emitted events to be added to the session.

  Args:
    invocation_context: The invocation context.
    request: The raw model request. Callback can mutate the request.
  """

  after_model_callback: AfterModelCallback | None = None
  """Called after the model is called.

  The emitted event will added to session before the final model response event.

  Args:
    invocation_context: The invocation context.
    generate_content_response: The raw model response, of which the content will
      be added to the event. Callback can mutate the content.
  """

  before_agent_callback: BeforeAgentCallback | None = None
  """Called before the agent is called.

  The emitted events will be added to the session.

  Args:
    invocation_context: InvocationContext,
  """

  after_agent_callback: AfterAgentCallback | None = None
  """Called after the agent is called.

  The emitted events will be added to the session.

  Args:
    invocation_context: InvocationContext,
  """

  before_tool_callback: BeforeToolCallback | None = None
  """Called before the tool is called.

  If you return an object, that object will be used as the tool response.
  Otherwise, the tool will be called.

  Args:
    invocation_context: InvocationContext,
    tool: The tool to be called.
    args: The arguments to the tool.
    tool_context: ToolContext,

  Returns:
    The tool response event or None to let the framework call the tool.
  """

  after_tool_callback: AfterToolCallback | None = None
  """Called after the tool is called.

  You have the chance to mutate the tool response in this callback.

  Args:
    invocation_context: InvocationContext,
    tool: The tool to be called.
    args: The arguments to the tool.
    tool_context: ToolContext,
    tool_response: The response from the tool.

  Returns:
    None
  """

  @model_validator(mode='before')
  @classmethod
  def validate_agent(cls, data: Any) -> Any:
    if not data['name'].isidentifier():
      raise ValueError(f'Agent name `{data["name"]}` is invalid.')
    return data

  # Get the model name from the agent or its parent agent.
  def get_model(self):
    agent = self
    while agent:
      if agent.model:
        return agent.model
      agent = agent.parent_agent
    raise ValueError(f'No model found for agent {self.name}.')

  def find_child(self, name: str) -> BaseAgent | None:
    """Finds the child agent with the given name recursively."""
    for child in self.children:
      if child.name == name:
        return child
      # Other agent types do not have children.
      if isinstance(child, Agent):
        result = child.find_child(name)
        if result:
          return result
    return None

  def find_agent(self, name: str) -> BaseAgent | None:
    """Similar to find_child, but also check itself."""
    if self.name == name:
      return self
    return self.find_child(name)

  def model_post_init(self, __context):
    for child in self.children:
      if child.parent_agent:
        logger.error(
            'Agent %s already has a parent agent %s.',
            child.name,
            child.parent_agent.name,
        )
        raise ValueError(
            f'Agent {child.name} already has a parent agent'
            f' {child.parent_agent.name}.'
        )
      child.parent_agent = self

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    with tracer.start_as_current_span(f'call_agent [{self.name}]'):
      # Always creates a new invocation context for the current agent.
      invocation_context = parent_context.model_copy(update={'agent': self})

      # Run before_agent_callback if it exists.
      if self.before_agent_callback:
        events = self.before_agent_callback(invocation_context)
        if events:
          yield from events
        if invocation_context.end_invocation:
          return

      # Run the flow.
      events = self.__resolved_flow(invocation_context)
      if events:
        yield from events
      if invocation_context.end_invocation:
        return

      # Run after_agent_callback if it exists.
      if self.after_agent_callback:
        events = self.after_agent_callback(invocation_context)
        if events:
          yield from events
        if invocation_context.end_invocation:
          return

  def run_as_tool(
      self,
      input_value: Union[BaseModel, str],
      input_context: dict[str, Any] | None = None,
      output_context: dict[str, Any] | None = None,
  ) -> BaseModel:
    invocation_id = 'tool_invocation'
    if self.input_schema:
      if isinstance(input_value, dict):
        input_value = self.input_schema.model_validate(input_value)
      if not isinstance(input_value, self.input_schema):
        raise ValueError(
            f'Input value {input_value} is not of type {self.input_schema}.'
        )
      content = types.Content(
          role='user',
          parts=[
              types.Part.from_text(
                  input_value.model_dump_json(exclude_none=True)
              )
          ],
      )
    else:
      content = types.Content(
          role='user',
          parts=[types.Part.from_text(input_value)],
      )
    artifact_service = InMemoryArtifactService()
    session_service = InMemorySessionService()
    session = session_service.create(context=input_context)
    session.events.append(
        Event(invocation_id=invocation_id, author='user', content=content)
    )
    last_event = None
    invocation_context = InvocationContext(
        artifact_service=artifact_service,
        session_service=session_service,
        invocation_id=invocation_id,
        agent=self,
        session=session,
        response_streaming=False,
    )
    for event in self.run(invocation_context):
      session_service.append_event(session, event)
      artifact_service.process_event(session.id, event)
      last_event = event

    # Save local session context to output_context that can be used outside.
    if output_context is not None:
      output_context.update(session.state)

    if self.output_schema:
      return self.output_schema.model_validate_json(
          last_event.content.parts[0].text
      )
    else:
      return last_event.content.parts[0].text

  @cached_property
  def children_dict(self) -> dict[str, BaseAgent]:
    """Returns a dict of children agents keyed by their names."""
    return {agent.name: agent for agent in self.children}

  @cached_property
  def resolved_model(self) -> str | BaseLlm:
    current_agent = self
    while current_agent:
      if current_agent.model:
        return current_agent.model
      current_agent = current_agent.parent_agent
    raise ValueError(f'No model found for agent {self.name}.')

  @cached_property
  def __resolved_flow(self) -> FlowCallable:
    if isinstance(self.flow, str):
      return FlowRegistry.new_flow(self.flow)
    if isinstance(self.flow, BaseFlow):
      return self.flow
    if isinstance(self.flow, Callable):
      return self.flow
    raise ValueError(f'Unsupported flow type: {type(self.flow)}')
