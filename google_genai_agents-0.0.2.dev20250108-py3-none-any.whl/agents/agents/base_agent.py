from abc import ABC
from abc import abstractmethod
from typing import Generator

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field

from agents.events import Event
from agents.sessions import Session

from ..artifacts import BaseArtifactService
from ..sessions import BaseSessionService


class BaseAgent(BaseModel, ABC):
  """Base class for all agents."""

  name: str
  """The agent's name.

  Agent name must be a unique Python identifier within the agent tree.
  """

  description: str = ''
  """One line description about the agent's capability.

  The model uses this to determine whether to delegate control to the agent.
  """

  parent_agent: 'BaseAgent | None' = Field(default=None, init=False)
  """The parent agent in the agent tree.

  Note that one agent cannot be added to two agents' children list.
  """

  @abstractmethod
  def run(
      self,
      parent_context: 'InvocationContext',
  ) -> Generator[Event, None, None]:
    pass


  def get_root_agent(self) -> 'BaseAgent | None':
    agent = self
    while agent:
      if agent.parent_agent is None:
        return agent
      agent = agent.parent_agent
    return None


# An invocation context represents the data of a single invocation of an agent.
#
# An invocation:
#   1. Starts with a user message and ends with a final response.
#   2. Can contain one or multiple agent calls.
#   3. Is handled by runner.run().
# An invocation runs an agent until it doesn not request to transfer to another
# agent.
#
# An agent call:
#   1. Is handled by agent.run().
#   2. Ends when agent.run() ends.
#
# An LLM agent call is an agent with a BaseLLMFlow.
# An LLM agent call can contain one or multiple steps.
# An LLM agent runs steps in a loop until:
#   1. A final reponse is generated.
#   2. The agent transfers to another agent.
#   3. The end_invocation is set to true by any callbacks or tools.
#
# A step:
#   1. Calls the LLM only once and yields its response.
#   2. Calls the tools and yields their responses if requested.
# The summarization of the function response is considered another step, since
# it is another llm call.
# A step ends when it's done calling llm and tools, or if the end_invocation
# is set to true at any time.
#
#
# ┌─────────────────────── invocation ──────────────────────────┐
# ┌──────────── llm_agent_call_1 ────────────┐ ┌─ agent_call_2 ─┐
# ┌──── step_1 ────────┐ ┌───── step_2 ──────┐
# [call_llm] [call_tool] [call_llm] [transfer]
class InvocationContext(BaseModel):
  model_config = ConfigDict(
      arbitrary_types_allowed=True,
  )

  artifact_service: BaseArtifactService
  session_service: BaseSessionService

  invocation_id: str
  agent: BaseAgent
  session: Session
  response_streaming: bool

  end_invocation: bool = False
