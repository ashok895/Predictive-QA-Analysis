import json
from typing import Generator
import requests
from ..events import Event
from .base_agent import BaseAgent
from .base_agent import InvocationContext


class RemoteAgent(BaseAgent):
  url: str

  def run(
      self,
      parent_context: InvocationContext,
  ) -> Generator[Event, None, None]:
    data = {
        'invocation_id': parent_context.invocation_id,
        'session': parent_context.session.model_dump(exclude_none=True),
    }
    events = requests.post(self.url, data=json.dumps(data))
    events.raise_for_status()
    for event in events.json():
      e = Event.model_validate(event)
      e.author = self.name
      yield e
