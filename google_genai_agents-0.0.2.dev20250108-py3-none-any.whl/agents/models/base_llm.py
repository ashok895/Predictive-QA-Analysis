import abc
from abc import abstractmethod
from typing import Callable
from typing import Generator

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from pydantic import field_validator

from ..tools import BaseTool
from ..tools.function_tool import FunctionTool


class LlmRequest(BaseModel):
  model: str
  contents: list[types.Content] | None = None
  config: types.GenerateContentConfig | None = None
  """Additional config for the generate content request.

  tools in generate_content_config should not be set.
  """
  tools_dict: dict[str, types.Tool] = Field(default_factory=dict, exclude=True)

  @field_validator('config', mode='after')
  @classmethod
  def validate_config(
      cls, config: types.GenerateContentConfig
  ) -> types.GenerateContentConfig:
    if not config:
      return types.GenerateContentConfig()
    if config.tools:
      raise ValueError('All tools must be set via Agent.tools.')
    if config.system_instruction:
      raise ValueError('System instruction must be set via Agent.instruction.')
    if config.response_schema:
      raise ValueError('Response schema must be set via Agent.output_schema.')
    return config.model_copy(deep=True)

  def append_instructions(self, instructions: list[str]) -> None:
    if self.config.system_instruction:
      self.config.system_instruction += '\n\n' + '\n\n'.join(instructions)
    else:
      self.config.system_instruction = '\n\n'.join(instructions)

  def append_tools(self, tools: list[BaseTool | Callable]) -> None:
    if not tools:
      return
    resolved_tools = [
        FunctionTool.from_function(tool) if isinstance(tool, Callable) else tool
        for tool in tools
    ]
    self.tools_dict.update({tool.name: tool for tool in resolved_tools})
    if not self.config.tools:
      self.config.tools = [types.Tool(function_declarations=[])]
    self.config.tools[0].function_declarations.extend(
        [tool.get_declaration() for tool in resolved_tools]
    )

  def set_output_schema(self, base_model: type[BaseModel]) -> None:
    self.config.response_schema = base_model
    self.config.response_mime_type = 'application/json'


class LlmResponse(types.GenerateContentResponse):
  def get_content(self) -> types.Content | None:
    return self.candidates[0].content if self.candidates else None


class BaseLlm(BaseModel):
  """The BaseLLM class."""

  model_config = ConfigDict(
      # This allows us to use arbitrary types in the model. E.g. PIL.Image.
      arbitrary_types_allowed=True,
  )

  model: str
  """The name of the LLM, e.g. gemini-1.5-flash or gemini-1.5-flash-001."""

  @staticmethod
  @abstractmethod
  def supported_models() -> list[str]:
    """Returns a list of supported models in regex."""
    pass

  @abc.abstractmethod
  def generate_content(
      self, llm_request: LlmRequest, stream: bool = False
  ) -> Generator[LlmResponse, None, None]:
    """Generates one content from the given contents and tools.

    Args:
      llm_request: LlmRequest, the request to send to the LLM.
      stream: bool = False, whether to do streaming call.

    Returns a generator of types.Content. For non-streaming call, it will only
      yield one Content. For streaming call, it may yield more than one content,
      but all yielded contents should be treated as one content by merging the
      parts list.
    """
    pass
