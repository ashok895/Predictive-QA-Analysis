"""Defines the interface to support a model."""

from .base_llm import BaseLlm
from .google_llm import Gemini
from .registry import LLMRegistry

__all__ = [
    'BaseLlm',
    'Gemini',
    'LLMRegistry',
]


for regex in Gemini.supported_models():
  LLMRegistry.register(Gemini)
