from datetime import datetime
import random
import string
from typing import Any
from typing import Optional

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field


class EventActions(BaseModel):
  model_config = ConfigDict(extra='forbid')

  skip_summarization: Optional[bool] = None
  """If true, it won't call model to summarize function response.

  Only used for function_response event.
  """

  state_delta: Optional[dict[str, object]] = None
  """Indicates that the event is updating the state with the given delta."""

  artifact_delta: Optional[dict[str, types.Part]] = None
  """Indicates that the event is updating an artifact."""

  pending: Optional[bool] = None
  """If true, the tool call is pending and the result is not yet available.

  Only used for function_call event.
  """

  transfer_to_agent: Optional[str] = None
  """If set, the event transfers to the specified agent."""

  escalate: Optional[bool] = None
  """The agent is escalating to a higher level agent."""

  def update_artifact(self, key: str, value: types.Part):
    if not isinstance(value, types.Part):
      raise ValueError(f'Value {value} is not a Part.')
    if not self.artifact_delta:
      self.artifact_delta = {}
    self.artifact_delta[key] = value

  def update_state(self, key: str, value: Any):
    if isinstance(value, BaseModel):
      value = value.model_dump(exclude_none=True)
    if not self.state_delta:
      self.state_delta = {}
    self.state_delta[key] = value


class Event(BaseModel):
  model_config = ConfigDict(extra='forbid')

  # TODO: Change to required field after session files are all migrated.
  invocation_id: str | None = None
  # The name of the agent that sent the event, or user.
  author: str
  content: types.Content = None
  actions: EventActions = Field(default_factory=EventActions)
  # Whether this is a greeting message. When this is true, the content is not
  # sent to the model for future conversation. This is because we found that
  # the agent transfer rate is low when the greeting message is present. Perhaps
  # because the root_agent thinks it can handle all requests based on the
  # greeting message.
  is_greeting: bool | None = None

  function_call_event_id: Optional[str] = None
  """The ID of the function call event that this event is responding to."""

  partial: Optional[bool] = None
  """partial is true for incomplete chunks from the LLM streaming response.

  The last chun's partial is False.
  """

  # TODO: Handle this natively.
  code_execution_event_type: Optional[str] = None
  """If set, the event is treated as a code execution event.

  Valid values are 'code', 'execution', and 'data'.
  """

  # The following are computed fields.
  # No not assign the ID. It will be assigned by the session.
  id: str = ''
  timestamp: float = Field(default_factory=lambda: datetime.now().timestamp())

  def model_post_init(self, __context):
    # Generates a random ID for the event.
    if not self.id:
      self.id = Event.new_id()

  def is_final_response(self) -> bool:
    if self.actions.skip_summarization:
      return True
    return (
        not self.get_function_calls()
        and not self.get_function_responses()
        and not self.partial
        and not self.code_execution_event_type
    )

  def get_function_calls(self) -> list[types.FunctionCall]:
    func_calls = []
    for part in self.content.parts:
      if part.function_call:
        func_calls.append(part.function_call)
    return func_calls

  def get_function_responses(self) -> list[types.FunctionResponse]:
    func_response = []
    for part in self.content.parts:
      if part.function_response:
        func_response.append(part.function_response)
    return func_response

  @classmethod
  def new_id(cls):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(8))

  @classmethod
  def from_function_response(
      cls, function_call_event, function_call, function_result
  ):
    content = types.Content(
        role='user',
        parts=[
            types.Part(
                function_response=types.FunctionResponse(
                    name=function_call.name, response=function_result
                )
            )
        ],
    )
    return cls(
        invocation_id=function_call_event.invocation_id,
        author=function_call_event.author,
        content=content,
        function_call_event_id=function_call_event.id,
    )

  @staticmethod
  def merge_async_function_response_events(
      async_function_response_events: list['Event'],
  ) -> 'Event':
    """Merges a list of function_response events into one event for async

    function_call.

    The key goal is to ensure:
    1. function_call and function_response are always of the same number.
    2. The function_call and function_response are consecutively in the content.

    Args:
      async_function_response_events: A list of function_response events.
        NOTE: function_response_events must fulfill these requirements: 1. The
          list is in increasing order of timestamp; 2. the first event is the
          initial function_reponse event; 3. all later events should contain at
          least one function_response part that related to the function_call
          event.
        Caveat: This implementation doesn't support when a parallel
          function_call event contains async function_call of the same name.

    Returns:
      A merged event, that is
        1. All later function_response will replace function_response part in
           the initial function_response event.
        2. All non-function_response parts will be appended to the part list of
           the initial function_response event.
    """
    if len(async_function_response_events) <= 1:
      raise ValueError('At least two function_response events are required.')

    merged_event = async_function_response_events[0].model_copy(deep=True)
    parts_in_merged_event: list[types.Part] = merged_event.content.parts  # type: ignore

    if not parts_in_merged_event:
      raise ValueError('There should be at least one function_response part.')

    part_indices_in_merged_event: dict[str, int] = {}
    for idx, part in enumerate(parts_in_merged_event):
      if part.function_response:
        func_name: str = part.function_response.name  # type: ignore
        part_indices_in_merged_event[func_name] = idx

    for event in async_function_response_events[1:]:
      if not event.content.parts:
        raise ValueError('There should be at least one function_response part.')

      for part in event.content.parts:
        if part.function_response:
          func_name: str = part.function_response.name  # type: ignore
          parts_in_merged_event[part_indices_in_merged_event[func_name]] = part
        else:
          parts_in_merged_event.append(part)

    return merged_event

  @staticmethod
  def merge_parallel_function_response_events(
      function_response_events: list['Event'],
  ) -> 'Event':

    if len(function_response_events) == 1:
      return function_response_events[0]
    merged_parts = []
    for event in function_response_events:
      if event.content:
        for part in event.content.parts or []:
          merged_parts.append(part)

    # Use the first event as the "base" for common attributes
    base_event = (
        function_response_events[0] if function_response_events else None
    )

    # Merge actions from all events
    # TODO: validate that pending actions are not cleared away
    merged_actions = EventActions()
    for event in function_response_events:
      merged_actions = merged_actions.model_copy(
          update=event.actions.model_dump()
      )

    # Create the new merged event
    merged_event = Event(
        invocation_id=Event.new_id(),
        author=base_event.author,
        content=types.Content(role='user', parts=merged_parts),
        actions=merged_actions,  # Optionally merge actions if required
    )

    # Use the base_event as the timestamp
    merged_event.timestamp = base_event.timestamp
    return merged_event
